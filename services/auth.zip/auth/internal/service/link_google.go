package service

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"

	platformerrors "tradedrift/platform/errors"
	"tradedrift/services/auth/internal/repository"
)

type linkTokenPayload struct {
	Sub    string `json:"sub"`
	Email  string `json:"email"`
	UserID string `json:"user_id"`
}

// LinkGoogleAccount securely links a verified Google identity to an existing
// password-based account after validating the user's password.
func (s *Service) LinkGoogleAccount(ctx context.Context, email, password, linkToken string) (*UserDTO, *TokenPairDTO, error) {
	if email == "" || password == "" || linkToken == "" {
		return nil, nil, platformerrors.New(platformerrors.CodeInvalidArgument, "email, password, and link_token are required")
	}

	email = normalizeEmail(email)
	redisKey := "auth:google_link:" + linkToken

	// 1. Retrieve link token data from Redis (do NOT delete yet)
	dataStr, err := s.rdb.Get(ctx, redisKey).Result()
	if err != nil {
		s.log.Warn("Failed to retrieve or expired Google link token", zap.Error(err))
		return nil, nil, platformerrors.New(platformerrors.CodeInvalidArgument, "invalid or expired link token. Please initiate Google sign-in again.")
	}

	var payload linkTokenPayload
	if err := json.Unmarshal([]byte(dataStr), &payload); err != nil {
		s.log.Error("Failed to unmarshal link token payload", zap.Error(err))
		return nil, nil, platformerrors.New(platformerrors.CodeInternal, "failed to process link token")
	}

	// 2. Verify target email matches the verified Google email
	if email != normalizeEmail(payload.Email) {
		s.log.Warn("Link email mismatch", zap.String("submitted", email), zap.String("tokenEmail", payload.Email))
		return nil, nil, platformerrors.New(platformerrors.CodeInvalidArgument, "submitted email does not match the Google identity")
	}

	// 3. Retrieve local account
	u, err := s.userRepo.GetByID(ctx, payload.UserID)
	if err != nil {
		s.log.Error("Failed to fetch user during account linking", zap.String("userID", payload.UserID), zap.Error(err))
		return nil, nil, err
	}
	if u == nil {
		return nil, nil, platformerrors.New(platformerrors.CodeNotFound, "user account not found")
	}

	// 4. Account status checks (reject pending verification, suspended or banned)
	if u.Status == "PENDING_VERIFICATION" {
		s.log.Warn("LinkGoogleAccount rejected: account pending verification", zap.String("userID", u.ID))
		return nil, nil, platformerrors.New(platformerrors.CodeAccountNotActive, "account is not verified. Please verify your email first.")
	}
	if u.Status == "SUSPENDED" || u.Status == "BANNED" {
		return nil, nil, platformerrors.New(platformerrors.CodePermissionDenied, fmt.Sprintf("your account has been %s", u.Status))
	}

	// 5. Passwordless accounts cannot be linked via password
	if u.PasswordHash == "" {
		s.log.Warn("LinkGoogleAccount rejected: account has no password", zap.String("userID", u.ID))
		return nil, nil, platformerrors.New(platformerrors.CodeFailedPrecondition, "account has no password configured. Please sign in with Google directly.")
	}

	// 6. Check brute-force lockout
	now := time.Now().UTC()
	if u.LockedUntil != nil && u.LockedUntil.After(now) {
		return nil, nil, platformerrors.New(platformerrors.CodeFailedPrecondition, "account is temporarily locked due to too many failed attempts")
	}

	// 7. Verify local password BEFORE consuming the link token
	if err := s.compareBcrypt(u.PasswordHash, password); err != nil {
		// Increment failed login attempt
		failedCount := u.FailedLoginAttempts + 1
		var lockUntil *time.Time
		if failedCount >= 5 {
			l := now.Add(15 * time.Minute)
			lockUntil = &l
		}
		_ = s.userRepo.TrackFailedLogin(ctx, u.ID, failedCount, lockUntil)
		// NOTE: We deliberately do NOT delete the link token here so the user can re-try typing their password
		return nil, nil, platformerrors.New(platformerrors.CodeInvalidCredentials, "incorrect account password")
	}

	// 8. ATOMIC TOKEN CONSUMPTION: Only consume the link token once password is authenticated.
	// Atomic DEL prevents concurrent requests from reusing the same link token.
	deletedCount, err := s.rdb.Del(ctx, redisKey).Result()
	if err != nil || deletedCount == 0 {
		s.log.Warn("Link token already consumed concurrently or expired", zap.String("linkToken", linkToken), zap.Error(err))
		return nil, nil, platformerrors.New(platformerrors.CodeInvalidArgument, "link token was already used or expired. Please sign in with Google again.")
	}

	// 9. Verify the Google sub is not already linked to another account
	existingIdent, err := s.identityRepo.GetByProviderAndUID(ctx, "google", payload.Sub)
	if err != nil {
		s.log.Error("Failed to check existing identity during link", zap.Error(err))
		return nil, nil, err
	}
	if existingIdent != nil && existingIdent.UserID != u.ID {
		return nil, nil, platformerrors.New(platformerrors.CodeAlreadyExists, "this Google account is already linked to a different TradeDrift profile")
	}

	// 10. Persist identity link (idempotent if already linked)
	if existingIdent == nil {
		newIdentity := &repository.UserAuthIdentity{
			ID:             uuid.NewString(),
			UserID:         u.ID,
			Provider:       "google",
			ProviderUserID: payload.Sub,
			Email:          payload.Email,
			CreatedAt:      now,
			UpdatedAt:      now,
		}
		if err := s.identityRepo.Create(ctx, newIdentity); err != nil {
			s.log.Error("Failed to save linked Google identity", zap.Error(err))
			return nil, nil, err
		}
	}

	// Ensure starter wallet is initialized (idempotent in wallet service)
	_ = s.walletCl.InitializeWallet(ctx, u.ID)

	// 11. Issue standard TradeDrift session tokens
	tokens, err := s.issueTokenPair(ctx, u.ID, u.Email, u.Role, u.TokenVersion)
	if err != nil {
		s.log.Error("Failed to issue tokens after account linking", zap.String("userID", u.ID), zap.Error(err))
		return nil, nil, err
	}

	_ = s.userRepo.ResetFailedLogin(ctx, u.ID, now)

	s.log.Info("Successfully linked Google identity to local account",
		zap.String("userID", u.ID),
		zap.String("email", u.Email),
	)

	return &UserDTO{
		ID:       u.ID,
		Email:    u.Email,
		Username: u.Username,
	}, tokens, nil
}

// ConnectGoogleAccount connects a Google identity to the currently authenticated user session.
func (s *Service) ConnectGoogleAccount(ctx context.Context, userID, idToken string) (string, error) {
	if s.googleValidator == nil {
		return "", platformerrors.New(platformerrors.CodeInternal, "google authentication is temporarily unavailable")
	}

	payload, err := s.googleValidator.Validate(ctx, idToken)
	if err != nil {
		return "", platformerrors.New(platformerrors.CodeInvalidCredentials, "invalid or expired Google token")
	}

	payload.Email = normalizeEmail(payload.Email)

	// 1. Verify Google sub is not already linked to anyone
	existing, err := s.identityRepo.GetByProviderAndUID(ctx, "google", payload.Subject)
	if err != nil {
		return "", err
	}
	if existing != nil {
		if existing.UserID == userID {
			return payload.Email, nil // Already connected to this user
		}
		return "", platformerrors.New(platformerrors.CodeAlreadyExists, "this Google account is already linked to another TradeDrift profile")
	}

	// 2. Verify user doesn't already have a Google identity
	current, err := s.identityRepo.GetByUserAndProvider(ctx, userID, "google")
	if err != nil {
		return "", err
	}
	if current != nil {
		return "", platformerrors.New(platformerrors.CodeAlreadyExists, "your account already has a connected Google account")
	}

	// 3. Create identity link
	now := time.Now().UTC()
	newIdentity := &repository.UserAuthIdentity{
		ID:             uuid.NewString(),
		UserID:         userID,
		Provider:       "google",
		ProviderUserID: payload.Subject,
		Email:          payload.Email,
		CreatedAt:      now,
		UpdatedAt:      now,
	}
	if err := s.identityRepo.Create(ctx, newIdentity); err != nil {
		return "", err
	}

	_ = s.walletCl.InitializeWallet(ctx, userID)

	s.log.Info("Connected Google identity from user session",
		zap.String("userID", userID),
		zap.String("googleEmail", payload.Email),
	)

	return payload.Email, nil
}
