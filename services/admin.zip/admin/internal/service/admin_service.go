package service

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"

	"tradedrift/services/admin/internal/client"
	"tradedrift/services/admin/internal/domain"
	"tradedrift/services/admin/internal/repository"
)

// AdminService orchestrates all administrative mutations.
// It is the owner of the Saga/Outbox/Audit invariants — downstream services
// (Auth, Wallet) own the actual user/session/wallet state.
type AdminService struct {
	txMgr    repository.TxManager
	opsRepo  repository.OperationsRepository
	authCli  *client.AuthClient
	walletCli *client.WalletClient
	log      *zap.Logger
}

// NewAdminService constructs the core admin service.
func NewAdminService(
	txMgr repository.TxManager,
	opsRepo repository.OperationsRepository,
	authCli *client.AuthClient,
	walletCli *client.WalletClient,
	log *zap.Logger,
) *AdminService {
	return &AdminService{
		txMgr:     txMgr,
		opsRepo:   opsRepo,
		authCli:   authCli,
		walletCli: walletCli,
		log:       log,
	}
}

// SuspendUserRequest contains all inputs for the user suspension flow.
type SuspendUserRequest struct {
	AdminID        string
	IdempotencyKey string
	RequestID      string
	TargetUserID   string
	Reason         string
	IPAddress      string
	UserAgent      string
}

// SuspendUser suspends a user by:
// 1. Checking idempotency (return cached response if operation already completed).
// 2. Atomically writing: audit_log + admin_operation + outbox_event + saga_task.
// 3. Attempting immediate Auth session invalidation (synchronous gRPC).
// 4. If Auth fails: the SagaWorker will retry via admin_saga_tasks.
func (s *AdminService) SuspendUser(ctx context.Context, req SuspendUserRequest) (*domain.AdminOperation, error) {
	// ── Idempotency check ──────────────────────────────────────────────────────
	existing, err := s.opsRepo.GetByIdempotencyKey(ctx, req.AdminID, req.IdempotencyKey)
	if err != nil {
		return nil, fmt.Errorf("SuspendUser: idempotency check: %w", err)
	}
	if existing != nil {
		if existing.Status == domain.OperationStatusProcessing {
			return nil, domain.ErrOperationInProgress
		}
		// Return cached result for COMPLETED and FAILED states.
		return existing, nil
	}

	now := time.Now().UTC()
	opID := uuid.New().String()
	auditID := uuid.New().String()
	eventID := uuid.New().String()
	sagaID := uuid.New().String()

	// ── Assemble envelope ─────────────────────────────────────────────────────
	envelope := domain.EventEnvelope{
		EventID:     eventID,
		OperationID: opID,
		RequestID:   req.RequestID,
		AdminID:     req.AdminID,
		Action:      domain.ActionSuspendUser,
		TargetID:    req.TargetUserID,
		Reason:      req.Reason,
		OccurredAt:  now,
	}
	envelopeBytes, _ := json.Marshal(envelope)

	sagaPayload, _ := json.Marshal(domain.SagaAuthPayload{
		UserID:    req.TargetUserID,
		Reason:    req.Reason,
		RequestID: req.RequestID,
	})

	txReq := repository.AdminOperationTxRequest{
		Operation: &domain.AdminOperation{
			ID:             opID,
			AdminID:        req.AdminID,
			IdempotencyKey: req.IdempotencyKey,
			RequestID:      req.RequestID,
			OperationType:  domain.OpSuspendUser,
			TargetID:       req.TargetUserID,
			Reason:         req.Reason,
			Status:         domain.OperationStatusProcessing,
			CreatedAt:      now,
			UpdatedAt:      now,
		},
		AuditLog: &domain.AuditLog{
			ID:          auditID,
			AdminID:     req.AdminID,
			OperationID: &opID,
			RequestID:   req.RequestID,
			Action:      domain.ActionSuspendUser,
			TargetType:  domain.TargetTypeUser,
			TargetID:    req.TargetUserID,
			Reason:      req.Reason,
			Metadata:    map[string]string{"ip": req.IPAddress},
			IPAddress:   req.IPAddress,
			UserAgent:   req.UserAgent,
			CreatedAt:   now,
		},
		OutboxEvent: &domain.OutboxEvent{
			ID:          eventID,
			OperationID: opID,
			Topic:       domain.TopicUserSuspended,
			Payload:     envelopeBytes,
			CreatedAt:   now,
		},
		SagaTask: &domain.SagaTask{
			ID:            sagaID,
			OperationID:   opID,
			TaskType:      domain.SagaTaskAuthInvalidateSessions,
			Payload:       sagaPayload,
			Status:        domain.SagaStatusPending,
			AttemptCount:  0,
			MaxAttempts:   10,
			NextAttemptAt: now,
			CreatedAt:     now,
			UpdatedAt:     now,
		},
	}

	result, err := s.txMgr.ExecAdminOperationTx(ctx, txReq)
	if err != nil {
		return nil, fmt.Errorf("SuspendUser: tx failed: %w", err)
	}

	// ── Attempt immediate Auth invalidation ───────────────────────────────────
	authErr := s.authCli.InvalidateUserSessions(ctx, req.TargetUserID, req.Reason, req.RequestID, opID)
	if authErr != nil {
		// Transient failure — SagaWorker will retry via admin_saga_tasks.
		s.log.Warn("SuspendUser: immediate auth invalidation failed; saga will retry",
			zap.String("operation_id", opID),
			zap.String("user_id", req.TargetUserID),
			zap.Error(authErr),
		)
		// Operation stays PROCESSING; saga task handles retry.
		return result.Operation, nil
	}

	// Auth succeeded — transition operation to COMPLETED.
	responseBody, _ := json.Marshal(map[string]string{"status": "suspended", "user_id": req.TargetUserID})
	if updateErr := s.opsRepo.UpdateStatus(ctx, opID, domain.OperationStatusCompleted, responseBody); updateErr != nil {
		s.log.Error("SuspendUser: failed to update operation to COMPLETED", zap.Error(updateErr))
	}
	result.Operation.Status = domain.OperationStatusCompleted
	result.Operation.ResponseBody = responseBody

	s.log.Info("SuspendUser: completed",
		zap.String("operation_id", opID),
		zap.String("user_id", req.TargetUserID),
		zap.String("request_id", req.RequestID),
	)
	return result.Operation, nil
}

// FreezeWalletRequest contains all inputs for the wallet freeze/unfreeze flow.
type FreezeWalletRequest struct {
	AdminID        string
	IdempotencyKey string
	RequestID      string
	TargetUserID   string
	Asset          string
	Freeze         bool
	Reason         string
	IPAddress      string
	UserAgent      string
}

// FreezeWallet freezes or unfreezes a user wallet asset.
// The gRPC call to Wallet is synchronous — no saga needed because FreezeWallet is idempotent.
func (s *AdminService) FreezeWallet(ctx context.Context, req FreezeWalletRequest) (*domain.AdminOperation, error) {
	// ── Idempotency check ──────────────────────────────────────────────────────
	existing, err := s.opsRepo.GetByIdempotencyKey(ctx, req.AdminID, req.IdempotencyKey)
	if err != nil {
		return nil, fmt.Errorf("FreezeWallet: idempotency check: %w", err)
	}
	if existing != nil {
		if existing.Status == domain.OperationStatusProcessing {
			return nil, domain.ErrOperationInProgress
		}
		return existing, nil
	}

	action := domain.ActionFreezeWallet
	topic := domain.TopicWalletFrozen
	if !req.Freeze {
		action = domain.ActionUnfreezeWallet
		topic = domain.TopicWalletUnfrozen
	}

	now := time.Now().UTC()
	opID := uuid.New().String()
	auditID := uuid.New().String()
	eventID := uuid.New().String()

	// ── Synchronous Wallet gRPC (no saga — naturally idempotent) ──────────────
	isFrozen, walletErr := s.walletCli.FreezeWallet(ctx, req.TargetUserID, req.Asset, req.Reason, req.RequestID, opID, req.Freeze)
	finalStatus := domain.OperationStatusCompleted
	var walletErrStr *string
	if walletErr != nil {
		s.log.Error("FreezeWallet: wallet gRPC failed",
			zap.String("user_id", req.TargetUserID),
			zap.String("asset", req.Asset),
			zap.Error(walletErr),
		)
		finalStatus = domain.OperationStatusFailed
		msg := walletErr.Error()
		walletErrStr = &msg
	}
	_ = walletErrStr

	envelope := domain.EventEnvelope{
		EventID: eventID, OperationID: opID, RequestID: req.RequestID,
		AdminID: req.AdminID, Action: action, TargetID: req.TargetUserID,
		Reason:     req.Reason,
		Metadata:   map[string]string{"asset": req.Asset, "is_frozen": fmt.Sprintf("%v", isFrozen)},
		OccurredAt: now,
	}
	envelopeBytes, _ := json.Marshal(envelope)
	responseBody, _ := json.Marshal(map[string]interface{}{
		"user_id": req.TargetUserID, "asset": req.Asset, "is_frozen": isFrozen,
	})

	txReq := repository.AdminOperationTxRequest{
		Operation: &domain.AdminOperation{
			ID:             opID,
			AdminID:        req.AdminID,
			IdempotencyKey: req.IdempotencyKey,
			RequestID:      req.RequestID,
			OperationType:  domain.OpFreezeWallet,
			TargetID:       req.TargetUserID,
			Reason:         req.Reason,
			Status:         finalStatus,
			ResponseBody:   responseBody,
			CreatedAt:      now,
			UpdatedAt:      now,
		},
		AuditLog: &domain.AuditLog{
			ID:          auditID,
			AdminID:     req.AdminID,
			OperationID: &opID,
			RequestID:   req.RequestID,
			Action:      action,
			TargetType:  domain.TargetTypeWallet,
			TargetID:    req.TargetUserID,
			Reason:      req.Reason,
			Metadata:    map[string]string{"asset": req.Asset, "ip": req.IPAddress},
			IPAddress:   req.IPAddress,
			UserAgent:   req.UserAgent,
			CreatedAt:   now,
		},
		OutboxEvent: &domain.OutboxEvent{
			ID:          eventID,
			OperationID: opID,
			Topic:       topic,
			Payload:     envelopeBytes,
			CreatedAt:   now,
		},
		SagaTask: nil, // Wallet freeze is idempotent — no saga needed
	}

	result, txErr := s.txMgr.ExecAdminOperationTx(ctx, txReq)
	if txErr != nil {
		return nil, fmt.Errorf("FreezeWallet: tx failed: %w", txErr)
	}

	if walletErr != nil {
		return nil, fmt.Errorf("FreezeWallet: wallet service error: %w", walletErr)
	}

	s.log.Info("FreezeWallet: completed",
		zap.String("operation_id", opID),
		zap.String("user_id", req.TargetUserID),
		zap.String("asset", req.Asset),
		zap.Bool("freeze", req.Freeze),
	)
	return result.Operation, nil
}

// HaltMarketRequest contains all inputs for halting a market.
type HaltMarketRequest struct {
	AdminID        string
	IdempotencyKey string
	RequestID      string
	MarketID       string
	Reason         string
	IPAddress      string
	UserAgent      string
}

// HaltMarket publishes a halt command to Kafka via the transactional outbox.
// The Matching Engine consumes this event and stops accepting new orders.
func (s *AdminService) HaltMarket(ctx context.Context, req HaltMarketRequest) (*domain.AdminOperation, error) {
	// ── Idempotency check ──────────────────────────────────────────────────────
	existing, err := s.opsRepo.GetByIdempotencyKey(ctx, req.AdminID, req.IdempotencyKey)
	if err != nil {
		return nil, fmt.Errorf("HaltMarket: idempotency check: %w", err)
	}
	if existing != nil {
		if existing.Status == domain.OperationStatusProcessing {
			return nil, domain.ErrOperationInProgress
		}
		return existing, nil
	}

	now := time.Now().UTC()
	opID := uuid.New().String()
	auditID := uuid.New().String()
	eventID := uuid.New().String()

	envelope := domain.EventEnvelope{
		EventID:     eventID,
		OperationID: opID,
		RequestID:   req.RequestID,
		AdminID:     req.AdminID,
		Action:      domain.ActionHaltMarket,
		TargetID:    req.MarketID,
		Reason:      req.Reason,
		OccurredAt:  now,
	}
	envelopeBytes, _ := json.Marshal(envelope)
	responseBody, _ := json.Marshal(map[string]string{"market_id": req.MarketID, "status": "halted"})

	txReq := repository.AdminOperationTxRequest{
		Operation: &domain.AdminOperation{
			ID:             opID,
			AdminID:        req.AdminID,
			IdempotencyKey: req.IdempotencyKey,
			RequestID:      req.RequestID,
			OperationType:  domain.OpHaltMarket,
			TargetID:       req.MarketID,
			Reason:         req.Reason,
			Status:         domain.OperationStatusCompleted, // committed = done for event-driven ops
			ResponseBody:   responseBody,
			CreatedAt:      now,
			UpdatedAt:      now,
		},
		AuditLog: &domain.AuditLog{
			ID:          auditID,
			AdminID:     req.AdminID,
			OperationID: &opID,
			RequestID:   req.RequestID,
			Action:      domain.ActionHaltMarket,
			TargetType:  domain.TargetTypeMarket,
			TargetID:    req.MarketID,
			Reason:      req.Reason,
			Metadata:    map[string]string{"ip": req.IPAddress},
			IPAddress:   req.IPAddress,
			UserAgent:   req.UserAgent,
			CreatedAt:   now,
		},
		OutboxEvent: &domain.OutboxEvent{
			ID:          eventID,
			OperationID: opID,
			Topic:       domain.TopicMarketHalted,
			Payload:     envelopeBytes,
			CreatedAt:   now,
		},
		SagaTask: nil, // Market halt is event-driven — Kafka delivery is at-least-once via outbox
	}

	result, txErr := s.txMgr.ExecAdminOperationTx(ctx, txReq)
	if txErr != nil {
		return nil, fmt.Errorf("HaltMarket: tx failed: %w", txErr)
	}

	s.log.Info("HaltMarket: committed to outbox",
		zap.String("operation_id", opID),
		zap.String("market_id", req.MarketID),
		zap.String("request_id", req.RequestID),
	)
	return result.Operation, nil
}
