package service

import (
	"context"
	"time"

	"go.uber.org/zap"

	"tradedrift/services/admin/internal/repository"
)

// OutboxPublisher polls admin_outbox for unpublished events and publishes them to Kafka.
// Uses SELECT ... FOR UPDATE SKIP LOCKED to avoid concurrent double-publishing.
// NOTE: This implementation logs events. For production Kafka, inject a kafka.Writer here.
type OutboxPublisher struct {
	outboxRepo repository.OutboxRepository
	log        *zap.Logger
	interval   time.Duration
	done       chan struct{}
	// kafkaWriter *kafka.Writer // inject for real Kafka publishing
}

// NewOutboxPublisher constructs the outbox background publisher.
func NewOutboxPublisher(
	outboxRepo repository.OutboxRepository,
	log *zap.Logger,
	interval time.Duration,
) *OutboxPublisher {
	return &OutboxPublisher{
		outboxRepo: outboxRepo,
		log:        log,
		interval:   interval,
		done:       make(chan struct{}),
	}
}

// Start launches the OutboxPublisher poll loop in the background.
func (p *OutboxPublisher) Start(ctx context.Context) {
	go func() {
		ticker := time.NewTicker(p.interval)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				p.publish(ctx)
			case <-ctx.Done():
				return
			case <-p.done:
				return
			}
		}
	}()
}

// Stop signals the OutboxPublisher to stop.
func (p *OutboxPublisher) Stop() {
	close(p.done)
}

// publish fetches a batch of unpublished events and delivers them.
// After successful delivery, marks each event as published atomically.
func (p *OutboxPublisher) publish(ctx context.Context) {
	events, err := p.outboxRepo.FetchUnpublished(ctx, 50)
	if err != nil {
		p.log.Error("OutboxPublisher: fetch failed", zap.Error(err))
		return
	}

	for _, event := range events {
		// TODO: Replace with real Kafka writer when kafka dependency is added.
		// err := p.kafkaWriter.WriteMessages(ctx, kafka.Message{
		//     Topic: event.Topic,
		//     Key:   []byte(event.OperationID),
		//     Value: event.Payload,
		// })
		// For now, log the event for observability.
		p.log.Info("OutboxPublisher: publishing event",
			zap.String("event_id", event.ID),
			zap.String("operation_id", event.OperationID),
			zap.String("topic", event.Topic),
		)

		if markErr := p.outboxRepo.MarkPublished(ctx, event.ID); markErr != nil {
			p.log.Error("OutboxPublisher: MarkPublished failed",
				zap.String("event_id", event.ID),
				zap.Error(markErr),
			)
			continue
		}
	}
}
