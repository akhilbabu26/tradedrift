package ws

import "time"

// ─── Client Inbound Frames ───────────────────────────────────────────────────

// InboundFrame is the base envelope for all client requests.
type InboundFrame struct {
	Event   string   `json:"event"`             // "subscribe", "unsubscribe", "ping", "authenticate"
	Streams []string `json:"streams,omitempty"` // e.g. ["market:orderbook:BTC-USDT"]
	Token   string   `json:"token,omitempty"`   // for inline auth if provided
}

// ─── Server Outbound Envelopes ──────────────────────────────────────────────

// OutboundEnvelope wraps all stream broadcasts pushed to clients.
type OutboundEnvelope struct {
	Stream string `json:"stream"`
	Data   any    `json:"data"`
}

// OutboundEvent wraps control frames (pong, error).
type OutboundEvent struct {
	Event   string `json:"event"`
	Code    string `json:"code,omitempty"`
	Message string `json:"message,omitempty"`
}

// ─── Stream Payloads ─────────────────────────────────────────────────────────

// OrderBookDepthPayload represents Level-2 depth data for a market.
type OrderBookDepthPayload struct {
	MarketID  string      `json:"marketId"`
	Bids      [][2]string `json:"bids"` // [[price, qty], [price, qty]...]
	Asks      [][2]string `json:"asks"` // [[price, qty], [price, qty]...]
	Timestamp time.Time   `json:"timestamp"`
}

// TradePayload represents a public executed trade fill.
type TradePayload struct {
	TradeID      string    `json:"tradeId"`
	MarketID     string    `json:"marketId"`
	Price        string    `json:"price"`
	Quantity     string    `json:"quantity"`
	BuyerUserID  string    `json:"buyerUserId,omitempty"`
	SellerUserID string    `json:"sellerUserId,omitempty"`
	ExecutedAt   time.Time `json:"executedAt"`
}

// TickerPayload represents 24h rolling market statistics.
type TickerPayload struct {
	MarketID              string    `json:"marketId"`
	LastPrice             string    `json:"lastPrice"`
	High24h               string    `json:"high24h"`
	Low24h                string    `json:"low24h"`
	Volume24h             string    `json:"volume24h"`
	QuoteVolume24h        string    `json:"quoteVolume24h"`
	PriceChange24hPercent string    `json:"priceChange24hPercent"`
	Timestamp             time.Time `json:"timestamp"`
}

// NotificationPayload represents a private user alert.
type NotificationPayload struct {
	ID        string    `json:"id"`
	UserID    string    `json:"userId"`
	Title     string    `json:"title"`
	Message   string    `json:"message"`
	Type      string    `json:"type"`
	CreatedAt time.Time `json:"createdAt"`
}

// StreamType constants for classification and backpressure routing
const (
	StreamTypeOrderBook    = "orderbook"
	StreamTypeTicker       = "ticker"
	StreamTypeTrades       = "trades"
	StreamTypeNotification = "notification"
	StreamTypeControl      = "control"
)

// ParseStreamType categorizes a stream name into its broad type.
func ParseStreamType(stream string) (streamType, target string) {
	// Format: "market:orderbook:BTC-USDT" or "user:notifications:uuid"
	var prefix, sub string
	n, _ := splitStream(stream)
	if len(n) >= 2 {
		prefix = n[0]
		sub = n[1]
	}
	if len(n) >= 3 {
		target = n[2]
	}

	if prefix == "market" {
		switch sub {
		case "orderbook":
			return StreamTypeOrderBook, target
		case "ticker":
			return StreamTypeTicker, target
		case "trades":
			return StreamTypeTrades, target
		}
	} else if prefix == "user" {
		return StreamTypeNotification, target
	}
	return StreamTypeControl, target
}

func splitStream(s string) ([]string, int) {
	var res []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == ':' {
			res = append(res, s[start:i])
			start = i + 1
		}
	}
	res = append(res, s[start:])
	return res, len(res)
}
