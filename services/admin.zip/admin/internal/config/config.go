package config

import (
	"os"
	"time"
)

// Config holds all configuration values for the Admin Service.
// Values are sourced from environment variables with sensible defaults.
type Config struct {
	Port string

	// PostgreSQL connection string for the admin database.
	PostgresDSN string

	// gRPC addresses of downstream services.
	AuthGRPCAddr   string
	WalletGRPCAddr string

	// JWT secret for validating admin access tokens (same key as auth service).
	JWTSecret string

	// Kafka broker addresses (comma-separated) for outbox publishing.
	KafkaBrokers string

	// Background worker intervals.
	OutboxInterval time.Duration // how often the outbox publisher polls
	SagaInterval   time.Duration // how often the SagaWorker polls
}

// Load reads configuration from environment variables.
func Load() *Config {
	port := getEnv("PORT", "8085")
	postgresDSN := getEnv("POSTGRES_DSN", "postgres://postgres:postgres@localhost:5432/tradedrift_admin?sslmode=disable")
	authGRPCAddr := getEnv("AUTH_GRPC_ADDR", "localhost:50051")
	walletGRPCAddr := getEnv("WALLET_GRPC_ADDR", "localhost:50052")
	jwtSecret := getEnv("JWT_SECRET", "super-secret-jwt-key-tradedrift-dev-32bytes")
	kafkaBrokers := getEnv("KAFKA_BROKERS", "localhost:9092")

	return &Config{
		Port:           port,
		PostgresDSN:    postgresDSN,
		AuthGRPCAddr:   authGRPCAddr,
		WalletGRPCAddr: walletGRPCAddr,
		JWTSecret:      jwtSecret,
		KafkaBrokers:   kafkaBrokers,
		OutboxInterval: 2 * time.Second,
		SagaInterval:   10 * time.Second,
	}
}

func getEnv(key, defaultValue string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return defaultValue
}
