package pricing

import (
	"testing"

	"github.com/shopspring/decimal"

	"tradedrift/services/liquidity-engine/internal/config"
)

func btcMarket() *config.MarketConfig {
	return &config.MarketConfig{
		MarketID:        "BTC-USDT",
		BaseAsset:       "BTC",
		QuoteAsset:      "USDT",
		TickSize:        decimal.RequireFromString("0.01"),
		LotSize:         decimal.RequireFromString("0.00001"),
		LevelCount:      12,
		MinOrderSize:    decimal.RequireFromString("0.00001"),
		SpreadBps:       4,
		ReferencePrice:  decimal.RequireFromString("96450.00"),
		MaxDeviationPct: decimal.RequireFromString("15"),
	}
}

func TestGenerateLadder_Count(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 12, 12)
	if len(levels) != 24 {
		t.Fatalf("expected 24 levels, got %d", len(levels))
	}

	// Count bids and asks
	bids, asks := 0, 0
	for _, l := range levels {
		if l.Side == "BUY" {
			bids++
		} else {
			asks++
		}
	}
	if bids != 12 {
		t.Errorf("expected 12 bids, got %d", bids)
	}
	if asks != 12 {
		t.Errorf("expected 12 asks, got %d", asks)
	}
}

func TestGenerateLadder_BidsBelowReference(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 12, 12)

	ref := mc.ReferencePrice
	for _, l := range levels {
		if l.Side == "BUY" {
			if !l.Price.LessThan(ref) {
				t.Errorf("bid %s price %s must be < reference %s", l.LevelID, l.Price, ref)
			}
		}
	}
}

func TestGenerateLadder_AsksAboveReference(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 12, 12)

	ref := mc.ReferencePrice
	for _, l := range levels {
		if l.Side == "SELL" {
			if !l.Price.GreaterThan(ref) {
				t.Errorf("ask %s price %s must be > reference %s", l.LevelID, l.Price, ref)
			}
		}
	}
}

func TestGenerateLadder_PricesTickRounded(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 12, 12)
	tick := mc.TickSize

	for _, l := range levels {
		// price mod tickSize == 0
		remainder := l.Price.Mod(tick)
		if !remainder.IsZero() {
			t.Errorf("level %s price %s is not tick-rounded (tick=%s, remainder=%s)",
				l.LevelID, l.Price, tick, remainder)
		}
	}
}

func TestGenerateLadder_QuantitiesLotRounded(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 12, 12)
	lot := mc.LotSize

	for _, l := range levels {
		remainder := l.Quantity.Mod(lot)
		if !remainder.IsZero() {
			t.Errorf("level %s quantity %s is not lot-rounded (lot=%s, remainder=%s)",
				l.LevelID, l.Price, lot, remainder)
		}
	}
}

func TestGenerateLadder_LevelIDFormat(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 12, 12)

	for _, l := range levels {
		if l.LevelID == "" {
			t.Error("found empty LevelID")
		}
		if l.MarketID != "BTC-USDT" {
			t.Errorf("wrong MarketID %q", l.MarketID)
		}
	}

	// First bid should be BID-01, last ask should be ASK-12
	if levels[0].LevelID != "MM-BTC-USDT-BID-01" {
		t.Errorf("expected MM-BTC-USDT-BID-01, got %s", levels[0].LevelID)
	}
	if levels[23].LevelID != "MM-BTC-USDT-ASK-12" {
		t.Errorf("expected MM-BTC-USDT-ASK-12, got %s", levels[23].LevelID)
	}
}

func TestGenerateLadder_BidPricesDecreasingFromRef(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 12, 12)

	// BID-01 should be closer to reference than BID-12
	// i.e. bids[0].Price > bids[11].Price
	var bids []PriceLevel
	for _, l := range levels {
		if l.Side == "BUY" {
			bids = append(bids, l)
		}
	}

	for i := 1; i < len(bids); i++ {
		if !bids[i].Price.LessThan(bids[i-1].Price) {
			t.Errorf("bid prices not descending: bids[%d]=%s >= bids[%d]=%s",
				i, bids[i].Price, i-1, bids[i-1].Price)
		}
	}
}

func TestGenerateLadder_AskPricesIncreasingFromRef(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 12, 12)

	var asks []PriceLevel
	for _, l := range levels {
		if l.Side == "SELL" {
			asks = append(asks, l)
		}
	}

	for i := 1; i < len(asks); i++ {
		if !asks[i].Price.GreaterThan(asks[i-1].Price) {
			t.Errorf("ask prices not ascending: asks[%d]=%s <= asks[%d]=%s",
				i, asks[i].Price, i-1, asks[i-1].Price)
		}
	}
}

func TestGenerateLadder_ReducedCount(t *testing.T) {
	mc := btcMarket()
	// Simulate inventory skew — only 6 asks
	levels := GenerateLadder(mc, 12, 6)
	if len(levels) != 18 {
		t.Fatalf("expected 18 levels (12 bids + 6 asks), got %d", len(levels))
	}
}

func TestGenerateLadder_ZeroLevels(t *testing.T) {
	mc := btcMarket()
	levels := GenerateLadder(mc, 0, 0)
	if len(levels) != 0 {
		t.Fatalf("expected 0 levels, got %d", len(levels))
	}
}

func TestRoundToTick(t *testing.T) {
	tick := decimal.RequireFromString("0.01")

	cases := []struct {
		input    string
		expected string
	}{
		{"96450.00", "96450.00"},
		{"96450.005", "96450.00"}, // floor
		{"96450.019", "96450.01"},
		{"96450.999", "96450.99"},
	}

	for _, c := range cases {
		in := decimal.RequireFromString(c.input)
		got := roundToTick(in, tick)
		exp := decimal.RequireFromString(c.expected)
		if !got.Equal(exp) {
			t.Errorf("roundToTick(%s) = %s, want %s", c.input, got, c.expected)
		}
	}
}

func TestRoundToLot(t *testing.T) {
	lot := decimal.RequireFromString("0.00001")

	cases := []struct {
		input    string
		expected string
	}{
		{"0.85000", "0.85000"},
		{"0.85001", "0.85001"},
		{"0.850009", "0.85000"}, // floor — avoid over-quoting
		{"0.850019", "0.85001"},
	}

	for _, c := range cases {
		in := decimal.RequireFromString(c.input)
		got := roundToLot(in, lot)
		exp := decimal.RequireFromString(c.expected)
		if !got.Equal(exp) {
			t.Errorf("roundToLot(%s) = %s, want %s", c.input, got, c.expected)
		}
	}
}
