package handler

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"time"

	platformjwt "tradedrift/platform/jwt"
)

type contextKey string

const (
	ctxKeyAdminID     contextKey = "adminID"
	ctxKeyRequestID   contextKey = "requestID"
	ctxKeyIdempotency contextKey = "idempotencyKey"
)

// AdminIDFromContext retrieves the validated admin's user ID from the request context.
func AdminIDFromContext(ctx context.Context) string {
	if v, ok := ctx.Value(ctxKeyAdminID).(string); ok {
		return v
	}
	return ""
}

// RequestIDFromContext retrieves the X-Request-ID from the request context.
func RequestIDFromContext(ctx context.Context) string {
	if v, ok := ctx.Value(ctxKeyRequestID).(string); ok {
		return v
	}
	return ""
}

// IdempotencyKeyFromContext retrieves the Idempotency-Key from the request context.
func IdempotencyKeyFromContext(ctx context.Context) string {
	if v, ok := ctx.Value(ctxKeyIdempotency).(string); ok {
		return v
	}
	return ""
}

// RequireAdmin validates the Bearer JWT and asserts Role == "admin".
// On success it injects admin_id and request_id into the context.
func RequireAdmin(jwtValidator *platformjwt.HMACValidator) func(http.HandlerFunc) http.HandlerFunc {
	return func(next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			authHeader := r.Header.Get("Authorization")
			if authHeader == "" || !strings.HasPrefix(authHeader, "Bearer ") {
				writeJSON(w, http.StatusUnauthorized, errorResponse("missing or malformed Authorization header"))
				return
			}
			tokenStr := strings.TrimPrefix(authHeader, "Bearer ")

			claims, err := jwtValidator.Validate(r.Context(), tokenStr)
			if err != nil {
				writeJSON(w, http.StatusUnauthorized, errorResponse("invalid or expired token"))
				return
			}
			if claims.Role != "admin" {
				writeJSON(w, http.StatusForbidden, errorResponse("admin role required"))
				return
			}

			// Extract or generate X-Request-ID for distributed tracing.
			requestID := r.Header.Get("X-Request-ID")
			if requestID == "" {
				requestID = generateRequestID()
			}

			ctx := r.Context()
			ctx = context.WithValue(ctx, ctxKeyAdminID, claims.UserID)
			ctx = context.WithValue(ctx, ctxKeyRequestID, requestID)
			next(w, r.WithContext(ctx))
		}
	}
}

// RequireIdempotencyKey enforces the presence of the Idempotency-Key header.
func RequireIdempotencyKey(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		key := r.Header.Get("Idempotency-Key")
		if key == "" {
			writeJSON(w, http.StatusBadRequest, errorResponse("Idempotency-Key header is required"))
			return
		}
		if len(key) > 128 {
			writeJSON(w, http.StatusBadRequest, errorResponse("Idempotency-Key must be 1-128 characters"))
			return
		}
		ctx := context.WithValue(r.Context(), ctxKeyIdempotency, key)
		next(w, r.WithContext(ctx))
	}
}

// LoggingMiddleware logs method, path, and duration for every request.
func LoggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rw := &statusRecorder{ResponseWriter: w, status: 200}
		next.ServeHTTP(rw, r)
		_ = rw.status // available for structured logging if needed
		_ = time.Since(start)
	})
}

// statusRecorder captures the HTTP status code for logging.
type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (r *statusRecorder) WriteHeader(code int) {
	r.status = code
	r.ResponseWriter.WriteHeader(code)
}

// writeJSON writes a JSON response with the given status code.
func writeJSON(w http.ResponseWriter, status int, data any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(data)
}

func errorResponse(msg string) map[string]string {
	return map[string]string{"error": msg}
}

func generateRequestID() string {
	// Simple timestamp-based fallback request ID.
	return "req-" + time.Now().UTC().Format("20060102150405.000000000")
}
