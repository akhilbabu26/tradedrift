-- +goose Up

-- 1. Markets — trading pair configuration and state
-- tick_size: minimum price increment (e.g. 0.01 USDT)
-- lot_size: minimum base asset quantity increment (e.g. 0.0001 BTC)
-- min_quantity: minimum order size in base asset
CREATE TABLE IF NOT EXISTS markets (
    id           VARCHAR(20) PRIMARY KEY,
    base_asset   VARCHAR(10) NOT NULL,
    quote_asset  VARCHAR(10) NOT NULL,
    tick_size    DECIMAL(30,10) NOT NULL CHECK (tick_size > 0),
    lot_size     DECIMAL(30,10) NOT NULL CHECK (lot_size > 0),
    min_quantity DECIMAL(30,10) NOT NULL DEFAULT 0.0001 CHECK (min_quantity > 0),
    status       VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed the three active markets
INSERT INTO markets (id, base_asset, quote_asset, tick_size, lot_size, status, min_quantity) VALUES
    ('BTC-USDT', 'BTC', 'USDT', 0.0100000000, 0.0001000000, 'ACTIVE', 0.0001000000),
    ('ETH-USDT', 'ETH', 'USDT', 0.0100000000, 0.0010000000, 'ACTIVE', 0.0010000000),
    ('SOL-USDT', 'SOL', 'USDT', 0.0010000000, 0.0100000000, 'ACTIVE', 0.0100000000)
ON CONFLICT (id) DO UPDATE SET
    base_asset   = EXCLUDED.base_asset,
    quote_asset  = EXCLUDED.quote_asset,
    tick_size    = EXCLUDED.tick_size,
    lot_size     = EXCLUDED.lot_size,
    status       = EXCLUDED.status,
    min_quantity = EXCLUDED.min_quantity;

-- 2. Market Trades — rolling trade ledger for 24h ticker calculations
-- executed_at is indexed DESC so range queries for ticker windows are fast
CREATE TABLE IF NOT EXISTS market_trades (
    id          UUID PRIMARY KEY,
    market_id   VARCHAR(20) NOT NULL,
    price       DECIMAL(30,10) NOT NULL CHECK (price > 0),
    quantity    DECIMAL(30,10) NOT NULL CHECK (quantity > 0),
    executed_at TIMESTAMPTZ NOT NULL,
    CONSTRAINT fk_market_trades_market FOREIGN KEY (market_id) REFERENCES markets(id)
);

CREATE INDEX IF NOT EXISTS idx_market_trades_rolling ON market_trades(market_id, executed_at DESC);

-- 3. OHLC Candles — aggregated price candles across multiple resolutions
-- open_trade_at / close_trade_at record the timestamps of the first/last trade in the window
-- resolution supports: 1m, 5m, 15m, 1h, 4h, 1d
CREATE TABLE IF NOT EXISTS ohlc_candles (
    market_id      VARCHAR(20) NOT NULL,
    resolution     VARCHAR(5)  NOT NULL,
    start_time     TIMESTAMPTZ NOT NULL,
    open_price     DECIMAL(30,10) NOT NULL CHECK (open_price > 0),
    high_price     DECIMAL(30,10) NOT NULL CHECK (high_price > 0),
    low_price      DECIMAL(30,10) NOT NULL CHECK (low_price > 0),
    close_price    DECIMAL(30,10) NOT NULL CHECK (close_price > 0),
    volume         DECIMAL(30,10) NOT NULL DEFAULT 0 CHECK (volume >= 0),
    quote_volume   DECIMAL(30,10) NOT NULL DEFAULT 0 CHECK (quote_volume >= 0),
    open_trade_at  TIMESTAMPTZ NOT NULL,
    close_trade_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (market_id, resolution, start_time),
    CONSTRAINT fk_candles_market FOREIGN KEY (market_id) REFERENCES markets(id),
    CONSTRAINT candles_resolution_check CHECK (resolution IN ('1m', '5m', '15m', '1h', '4h', '1d'))
);

CREATE INDEX IF NOT EXISTS idx_candles_time ON ohlc_candles(market_id, resolution, start_time DESC);

-- +goose Down
DROP INDEX IF EXISTS idx_candles_time;
DROP TABLE IF EXISTS ohlc_candles;
DROP INDEX IF EXISTS idx_market_trades_rolling;
DROP TABLE IF EXISTS market_trades;
DROP TABLE IF EXISTS markets;
