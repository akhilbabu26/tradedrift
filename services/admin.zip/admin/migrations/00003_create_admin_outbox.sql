-- +goose Up
-- Table: admin_outbox
-- Transactional outbox for at-least-once Kafka event publishing.
-- Committed atomically with the admin_operations row inside the same DB transaction.

CREATE TABLE IF NOT EXISTS admin_outbox (
    id              UUID         PRIMARY KEY,              -- event_id (UUIDv7)
    operation_id    UUID         NOT NULL REFERENCES admin_operations(id),
    topic           VARCHAR(128) NOT NULL,
    payload         JSONB        NOT NULL,
    published       BOOLEAN      NOT NULL DEFAULT FALSE,
    published_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Partial index: outbox_publisher only scans unpublished events.
CREATE INDEX IF NOT EXISTS idx_admin_outbox_unpublished
    ON admin_outbox(created_at ASC)
    WHERE published = FALSE;

-- +goose Down
DROP TABLE IF EXISTS admin_outbox;
