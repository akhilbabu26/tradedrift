# TradeDrift — Market Service

> **Status:** ✅ Designed (V1)
> **Document:** 12_Market_Service.md
> **Service:** Market Service
> **Version:** V1.1
> **Last Updated:** July 2026
> Revision notes: V1.1 fixes architectural alignment: (1) documents the Order Service fail-closed validation policy when the market config cache is cold/expired and Market Service is down; (2) specifies that the candle aggregation idempotency log write and all 5 resolution candle upserts must execute in a single atomic transaction; (3) aligns the Redis ticker hash key format to `ticker:{market_id}` with the Portfolio Service.

---

## Purpose

The Market Service manages the **exchange's trading pair configuration** and serves **read-side public market data** (order books, 24h tickers, and historical OHLC candles).

Its responsibilities are:

1. **Own the `markets` configuration ledger** (valid trading pairs with tick size, lot size, and active status).
2. **Expose REST APIs** for listing markets, fetching the active order book depth, fetching 24h ticker statistics, and fetching historical OHLC candles.
3. **Expose gRPC APIs** for internal services (e.g. Matching Engine to load market parameters at startup, Order Service to validate orders).
4. **Aggregate and write OHLC candles** to Postgres by consuming `TradeExecuted` Kafka events.
5. **Update and cache rolling 24h ticker statistics** in Redis.

---

## Out of Scope

| Concern | Owning Service |
|---|---|
| In-memory order matching & L2 book updates | Matching Engine |
| Settlement saga processing | Settlement Service |
| User trade history / fills ledger | Trade Service |
| User portfolio holdings & valuation | Portfolio Service |
| Real-time WebSocket event streaming | Notification Service |

---

## 1. System Architecture & Context

```
                         Matching Engine
                           │          │
        pushes L2 depth    │          │ publishes
        directly to Redis  │          │ TradeExecuted
                           ▼          ▼
             Redis: orderbook       Kafka: TradeExecuted
                     │                │
                     │                ▼
                     │       Market Service Consumer
                     │        ├── Update Postgres candles (1m, 5m, 15m, 1h, 1d)
                     │        └── Update Postgres trades log / Redis ticker
                     ▼                │
            Market Service REST API ◄─┘
            (GET /orderbook, /candles, /ticker)
```

- **Order Book Path (Redis):** The Matching Engine pushes a JSON L2 depth snapshot (`orderbook:{market_id}`) directly to Redis after matching. The Market Service bypasses the database completely and reads from Redis to serve `GET /markets/{id}/orderbook`.
- **Candles Path (Kafka):** Market Service consumes `TradeExecuted` from Kafka. Since it needs instant feedback for charts and tickers, it reacts to executions, not settlement.

---

## 2. Bootstrapping & Seeding

Markets are created and populated via database migrations.

### 2.1 Initial Market List (V1)

| Market ID | Base Asset | Quote Asset | Tick Size (Min Price Step) | Lot Size (Min Qty Step) |
|---|---|---|---|---|
| `BTC_USDT` | `BTC` | `USDT` | `0.01` | `0.0001` |
| `ETH_USDT` | `ETH` | `USDT` | `0.01` | `0.001` |
| `SOL_USDT` | `SOL` | `USDT` | `0.001` | `0.01` |

### 2.2 Bootstrapping script
Seeding is handled via standard SQL migrations checked into the repository (e.g., `market-service/db/migrations/0002_seed_initial_markets.up.sql`) to guarantee repeatable environments.

---

## 3. Database Schema

```sql
-- Configures trading pair rules
CREATE TABLE markets (
    id            VARCHAR(20) PRIMARY KEY,             -- e.g. "BTC_USDT"
    base_asset    VARCHAR(10) NOT NULL,                -- e.g. "BTC"
    quote_asset   VARCHAR(10) NOT NULL,                -- e.g. "USDT"
    tick_size     DECIMAL(30,10) NOT NULL,             -- min price step increment (e.g. 0.01)
    lot_size      DECIMAL(30,10) NOT NULL,             -- min quantity step increment (e.g. 0.0001)
    is_enabled    BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Stores trade records for 24h ticker calculations
CREATE TABLE market_trades (
    id            UUID PRIMARY KEY,                    -- = trade_id
    market_id     VARCHAR(20) NOT NULL,
    price         DECIMAL(30,10) NOT NULL,
    quantity      DECIMAL(30,10) NOT NULL,
    executed_at   TIMESTAMPTZ NOT NULL
);

CREATE INDEX idx_market_trades_rolling ON market_trades(market_id, executed_at DESC);

-- Stores candles across resolutions
CREATE TABLE ohlc_candles (
    market_id     VARCHAR(20) NOT NULL,
    resolution    VARCHAR(5) NOT NULL,                 -- '1m' | '5m' | '15m' | '1h' | '1d'
    start_time    TIMESTAMPTZ NOT NULL,                -- start of resolution window
    open_price    DECIMAL(30,10) NOT NULL,
    high_price    DECIMAL(30,10) NOT NULL,
    low_price     DECIMAL(30,10) NOT NULL,
    close_price   DECIMAL(30,10) NOT NULL,
    volume        DECIMAL(30,10) NOT NULL DEFAULT 0,   -- base asset traded volume
    quote_volume  DECIMAL(30,10) NOT NULL DEFAULT 0,   -- quote asset traded volume (volume * price)
    PRIMARY KEY (market_id, resolution, start_time)
);

CREATE INDEX idx_candles_time ON ohlc_candles(market_id, resolution, start_time DESC);
```

**Schema notes:**
- `DECIMAL(30,10)` — matches the `MONETARY_PRECISION` standard in `Glossary.md`.
- No outbox table is required for Market Service, as it does not publish integration events in V1.

---

## 4. Candle Aggregation (On-Write Strategy)

Market Service consumes `TradeExecuted` events from Kafka and aggregates them dynamically into the `ohlc_candles` table.

```
                   Kafka consumer receives TradeExecuted
                                    │
                                    ▼
                     For resolutions (1m, 5m, 15m, 1h, 1d):
                     Calculate start_time window boundary
                                    │
                                    ▼
                UPSERT ohlc_candles row for resolution + start_time
                ON CONFLICT (market_id, resolution, start_time)
                DO UPDATE SET
                   high_price   = MAX(high_price, EXCLUDED.high_price),
                   low_price    = MIN(low_price, EXCLUDED.low_price),
                   close_price  = EXCLUDED.close_price,
                   volume       = volume + EXCLUDED.volume,
                   quote_volume = quote_volume + EXCLUDED.quote_volume
```

* **Formula for start_time:**
  * For resolution $R$ (e.g. 15 minutes): `start_time = truncate(executed_at) to closest previous R-minute boundary`.
* **Idempotency & Atomicity:**
  `TradeExecuted` has at-least-once delivery. To prevent double-aggregating volume, the consumer deduplicates incoming trades using a local `processed_trades` log or a unique constraint catch on `market_trades.id = trade_id`. 
  **Atomic Transaction Rule:** The trade deduplication log write (`INSERT INTO market_trades`) and the upserts of all five resolution candles (1m, 5m, 15m, 1h, 1d) must execute inside a **single atomic database transaction**. This prevents partial-failure states where some resolutions are updated while others are skipped, ensuring strict data consistency across all chart resolutions.

---

## 5. Ticker Statistics Engine (24h Rolling Window)

The 24h ticker statistics (high, low, volume, last price, price change percent) are stored in Redis under the hash key `ticker:{market_id}`.

### 5.1 Update Loop (Option A)
To prevent complex in-memory state tracking, Market Service runs a background ticker calculations job every **10 seconds**:

1. For each active market, execute:
   ```sql
   SELECT 
       MIN(price) as low_24h,
       MAX(price) as high_24h,
       SUM(quantity) as volume_24h,
       (SELECT price FROM market_trades WHERE market_id = $1 AND executed_at > NOW() - INTERVAL '24 hours' ORDER BY executed_at ASC LIMIT 1) as open_24h,
       (SELECT price FROM market_trades WHERE market_id = $1 ORDER BY executed_at DESC LIMIT 1) as last_price
   FROM market_trades
   WHERE market_id = $1 
     AND executed_at > NOW() - INTERVAL '24 hours';
   ```
2. Calculate:
   `price_change_percent_24h = ((last_price - open_24h) / open_24h) * 100`
3. Write/refresh the stats in Redis key `ticker:{market_id}`.

---

## 6. Admin API & Validation

Market Service exposes admin endpoints for trading pair management. They check for a `role` claim in the request context (forwarded by the API Gateway from the JWT). Only `"role": "admin"` is permitted.

### `POST /admin/markets`
- **Payload:** `id` (e.g. `BTC_USDT`), `base_asset`, `quote_asset`, `tick_size`, `lot_size`
- **Validation:**
  - `tick_size > 0` and `lot_size > 0`.
  - Makes a gRPC call to `Wallet.GetSupportedAssets()` and validates both `base_asset` and `quote_asset` exist in the returned list. If not, rejects with `400 Bad Request`.
- **Immutability:** `tick_size` and `lot_size` are immutable once the market is created.

### `PATCH /admin/markets/{id}`
- **Payload:** `is_enabled` (boolean)
- **Behavior:** Toggles trading pair status. Modifying status does not delete open orders or shut down the matching engine. It only triggers the Order Service cache lookup.
- **Fail-closed Policy (Downstream):** If the Market Service is completely unreachable and the Order Service's local cache is cold/expired, the Order Service must **fail-closed** and reject all incoming order placement requests for that market (returning a `market_configuration_unavailable` or `service_unavailable` error) to prevent orders with invalid parameters from corrupting the matching logic.

---

## 7. Match Engine Provisioning & Disabling Runbooks

### 7.1 Runbook: Adding a New Market
1. Admin registers the new pair via `POST /admin/markets`.
2. Admin manually deploys a new instance of the Matching Engine configured with environment variable `MARKET_ID = NEW_PAIR` and partition maps.
3. The new ME instance starts, registers itself, checks Postgres checkpoints (cold start = 0), and begins consuming its dedicated Kafka partition.

### 7.2 Runbook: Disabling & Decommissioning a Market
To prevent race conditions where in-flight orders are published to Kafka while a Matching Engine partition consumer is shutting down:
1. **Disable:** Admin toggles market status to `is_enabled = FALSE` via `PATCH /admin/markets/{id}`.
2. **Cool-down (15 seconds):** Wait 15 seconds. The Order Service's market status cache TTL is 10 seconds. Waiting 15 seconds ensures the cache has fully expired and all in-flight orders submitted during the transition window have been consumed and processed by the Matching Engine. The Matching Engine instance **remains running** during this window.
3. **Purge Open Orders:** Admin calls Order Service's admin endpoint `POST /admin/orders/cancel-all?market_id={id}` to cancel all open resting orders.
4. **ME Termination:** Once the book is empty and the cool-down has passed, the administrator terminates the Matching Engine instance container.

---

## 8. REST API

Public read-only endpoints.

### `GET /markets`
- Returns a list of all active trading pairs.

### `GET /markets/{market_id}/orderbook`
- Serves Level 2 orderbook depth directly from Redis `orderbook:{market_id}`.
- **Response:**
  ```json
  {
    "bids": [["58200.00", "0.25"], ["58190.00", "1.10"]],
    "asks": [["58210.00", "0.05"], ["58220.00", "0.95"]],
    "timestamp": 1799298302000
  }
  ```

### `GET /markets/{market_id}/ticker`
- Returns rolling 24h price change, high, low, volume, and last price from Redis `ticker:{market_id}`.

### `GET /markets/{market_id}/candles`
- Query params: `resolution` ('1m'|'5m'|'15m'|'1h'|'1d'), `from` (timestamp), `to` (timestamp).
- Returns the historical candles array sorted by `start_time` ASC.

---

## 9. gRPC API (Internal)

```protobuf
service MarketService {
    rpc GetMarket(GetMarketRequest)
        returns (MarketResponse);

    rpc ListMarkets(ListMarketsRequest)
        returns (ListMarketsResponse);
}

message GetMarketRequest   { string market_id = 1; }
message ListMarketsRequest {}

message MarketResponse {
    string id          = 1;
    string base_asset  = 2;
    string quote_asset = 3;
    string tick_size   = 4;
    string lot_size    = 5;
    bool   is_enabled  = 6;
}
message ListMarketsResponse {
    repeated MarketResponse markets = 1;
}
```

- **Order Service:** Calls `GetMarket` (cached with 10s TTL) to check if the market exists and is active before accepting orders.
- **Matching Engine:** Calls `GetMarket` at startup to fetch tick and lot sizes.

---

## 10. Service Invariants

- **MI-1 (Immutability of Grid):** `tick_size` and `lot_size` columns on `markets` can never be updated after creation.
- **MI-2 (Immutability of History):** `market_trades` and `ohlc_candles` are append-only (candles are updated via upserts, never deleted).
- **MI-3 (Wallet Asset Integrity):** New markets can only be created using base and quote assets that exist in Wallet Service's `GetSupportedAssets` query.
- **MI-4 (Redis Book Source):** Order books are always served from Redis, which is maintained as a write-through replica by the Matching Engine.
- **MI-5 (Admin Authorization):** Admin writes require the caller's JWT role claim to equal `"admin"`.
