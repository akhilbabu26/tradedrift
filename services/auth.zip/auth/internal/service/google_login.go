package service

import (
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"strings"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"

	platformerrors "tradedrift/platform/errors"
	"tradedrift/services/auth/internal/repository"
)

var usernameSanitizeRegex = regexp.MustCompile(`[^a-zA-Z0-9_]`)

// GoogleLogin handles ID token verification, existing identity lookup,
// safe account-linking detection, or atomic new user creation.
func (s *Service) GoogleLogin(ctx context.Context, idToken string) (*UserDTO, *TokenPairDTO, *LinkRequiredDTO, error) {
	if s.googleValidator == nil {
		s.log.Error("Google token validator is not configured")
		return nil, nil, nil, platformerrors.New(platformerrors.CodeInternal, "google authentication is temporarily unavailable")
	}

	// 1. Verify Google ID token (never log raw token)
	payload, err := s.googleValidator.Validate(ctx, idToken)
	if err != nil {
		s.log.Warn("Google login token validation failed", zap.Error(err))
		return nil, nil, nil, platformerrors.New(platformerrors.CodeInvalidCredentials, "invalid or expired Google token")
	}

	// Normalize email to prevent casing mismatch issues
	payload.Email = normalizeEmail(payload.Email)
	now := time.Now().UTC()

	// 2. PRIMARY CHECK: Look up by Google sub first (identity already linked)
	identity, err := s.identityRepo.GetByProviderAndUID(ctx, "google", payload.Subject)
	if err != nil {
		s.log.Error("Failed to query user auth identity by sub", zap.Error(err))
		return nil, nil, nil, err
	}

	if identity != nil {
		// Existing linked user found
		u, err := s.userRepo.GetByID(ctx, identity.UserID)
		if err != nil {
			s.log.Error("Failed to query user by linked ID", zap.String("userID", identity.UserID), zap.Error(err))
			return nil, nil, nil, err
		}
		if u == nil {
			s.log.Error("Linked user record not found in users table", zap.String("userID", identity.UserID))
			return nil, nil, nil, platformerrors.New(platformerrors.CodeNotFound, "user account not found")
		}

		// Enforce account status restrictions (reject pending, suspended or banned)
		if u.Status == "PENDING_VERIFICATION" {
			s.log.Warn("Google login rejected: account pending verification", zap.String("userID", u.ID))
			return nil, nil, nil, platformerrors.New(platformerrors.CodeAccountNotActive, "account is not verified. Please verify your email first.")
		}
		if u.Status == "SUSPENDED" || u.Status == "BANNED" {
			s.log.Warn("Google login rejected: account suspended or banned", zap.String("userID", u.ID), zap.String("status", u.Status))
			return nil, nil, nil, platformerrors.New(platformerrors.CodePermissionDenied, fmt.Sprintf("your account has been %s", u.Status))
		}

		// Self-healing: ensure starter wallet is initialized (idempotent in wallet service)
		_ = s.walletCl.InitializeWallet(ctx, u.ID)

		// Issue session tokens
		tokens, err := s.issueTokenPair(ctx, u.ID, u.Email, u.Role, u.TokenVersion)
		if err != nil {
			s.log.Error("Failed to issue tokens for Google login", zap.String("userID", u.ID), zap.Error(err))
			return nil, nil, nil, err
		}

		_ = s.userRepo.ResetFailedLogin(ctx, u.ID, now)

		return &UserDTO{
			ID:       u.ID,
			Email:    u.Email,
			Username: u.Username,
		}, tokens, nil, nil
	}

	// 3. SECONDARY CHECK: No Google link, but does email exist in users table?
	existingUser, err := s.userRepo.GetByIdentifier(ctx, payload.Email)
	if err != nil {
		s.log.Error("Failed to query user by email", zap.Error(err))
		return nil, nil, nil, err
	}

	if existingUser != nil {
		// Enforce account restrictions before offering linking
		if existingUser.Status == "PENDING_VERIFICATION" {
			s.log.Warn("Google login rejected: local account pending verification", zap.String("userID", existingUser.ID))
			return nil, nil, nil, platformerrors.New(platformerrors.CodeAccountNotActive, "an account with this email exists but is pending email verification. Please verify your email first before linking.")
		}
		if existingUser.Status == "SUSPENDED" || existingUser.Status == "BANNED" {
			return nil, nil, nil, platformerrors.New(platformerrors.CodePermissionDenied, fmt.Sprintf("your account has been %s", existingUser.Status))
		}

		// Check if account has no password (e.g., created via another OAuth provider)
		if existingUser.PasswordHash == "" {
			return nil, nil, nil, platformerrors.New(platformerrors.CodeFailedPrecondition, "an account with this email exists without a password. Please sign in directly.")
		}

		// Safe policy: Do NOT automatically merge. Require password verification.
		linkToken := uuid.NewString()
		linkData := map[string]string{
			"sub":     payload.Subject,
			"email":   payload.Email,
			"user_id": existingUser.ID,
		}
		dataBytes, _ := json.Marshal(linkData)

		// Store in Redis with 5-minute TTL
		redisKey := "auth:google_link:" + linkToken
		if err := s.rdb.Set(ctx, redisKey, string(dataBytes), 5*time.Minute).Err(); err != nil {
			s.log.Error("Failed to store Google link token in Redis", zap.Error(err))
			return nil, nil, nil, platformerrors.New(platformerrors.CodeInternal, "failed to initiate account linking")
		}

		s.log.Info("Google login requires password confirmation to link account",
			zap.String("userID", existingUser.ID),
			zap.String("email", payload.Email),
		)

		return nil, nil, &LinkRequiredDTO{
			LinkToken: linkToken,
			Email:     payload.Email,
			Message:   "An account with this email already exists. Please verify your password to securely link your Google account.",
		}, nil
	}

	// 4. BRAND NEW USER: Atomically create user + identity mapping + outbox event in PostgreSQL
	userID := uuid.NewString()
	username := s.deriveUniqueUsername(ctx, payload.Name, payload.Email)

	newUser := &repository.User{
		ID:                  userID,
		Email:               payload.Email,
		Username:            username,
		PasswordHash:        "", // Stored as NULL in PostgreSQL
		TokenVersion:        1,
		Role:                "user",
		Status:              "VERIFIED",
		FailedLoginAttempts: 0,
		EmailVerifiedAt:     &now,
		CreatedAt:           now,
		UpdatedAt:           now,
	}

	identityRecord := &repository.UserAuthIdentity{
		ID:             uuid.NewString(),
		UserID:         userID,
		Provider:       "google",
		ProviderUserID: payload.Subject,
		Email:          payload.Email,
		CreatedAt:      now,
		UpdatedAt:      now,
	}

	eventID := uuid.NewString()
	eventPayload, _ := json.Marshal(map[string]string{
		"user_id":  userID,
		"email":    payload.Email,
		"username": username,
	})

	if err := s.identityRepo.CreateUserWithIdentity(ctx, newUser, identityRecord, eventID, eventPayload); err != nil {
		// Handle potential race condition: another request might have created the identity concurrently
		existingIdent, checkErr := s.identityRepo.GetByProviderAndUID(ctx, "google", payload.Subject)
		if checkErr == nil && existingIdent != nil {
			u, fetchErr := s.userRepo.GetByID(ctx, existingIdent.UserID)
			if fetchErr == nil && u != nil {
				tokens, tokErr := s.issueTokenPair(ctx, u.ID, u.Email, u.Role, u.TokenVersion)
				if tokErr == nil {
					return &UserDTO{ID: u.ID, Email: u.Email, Username: u.Username}, tokens, nil, nil
				}
			}
		}

		s.log.Error("Failed to atomically create new user from Google signup", zap.Error(err))
		return nil, nil, nil, err
	}

	// 5. Initialize starter wallet (10,000 USDT mock balance) with durable retry
	var walletErr error
	for attempt := 1; attempt <= 3; attempt++ {
		walletCtx, walletCancel := context.WithTimeout(ctx, 4*time.Second)
		walletErr = s.walletCl.InitializeWallet(walletCtx, userID)
		walletCancel()
		if walletErr == nil {
			break
		}
		s.log.Warn("Retrying wallet initialization for new Google user",
			zap.String("userID", userID),
			zap.Int("attempt", attempt),
			zap.Error(walletErr),
		)
		time.Sleep(100 * time.Millisecond)
	}

	if walletErr != nil {
		s.log.Error("Critical: Failed to initialize starter wallet for new Google user",
			zap.String("userID", userID),
			zap.Error(walletErr),
		)
		return nil, nil, nil, platformerrors.Wrap(walletErr, platformerrors.CodeInternal, "account created, but starter wallet initialization failed. Please retry sign-in.")
	}

	// 6. Issue session tokens
	tokens, err := s.issueTokenPair(ctx, userID, payload.Email, "user", 1)
	if err != nil {
		s.log.Error("Failed to issue session tokens for new Google user", zap.String("userID", userID), zap.Error(err))
		return nil, nil, nil, err
	}

	s.log.Info("Successfully registered and authenticated new Google user",
		zap.String("userID", userID),
		zap.String("email", payload.Email),
	)

	return &UserDTO{
		ID:       userID,
		Email:    payload.Email,
		Username: username,
	}, tokens, nil, nil
}

// deriveUniqueUsername generates a valid, alphanumeric username between 3 and 32 characters.
func (s *Service) deriveUniqueUsername(ctx context.Context, name, email string) string {
	base := strings.TrimSpace(name)
	if base == "" {
		parts := strings.Split(email, "@")
		base = parts[0]
	}

	// Remove non-alphanumeric chars
	sanitized := usernameSanitizeRegex.ReplaceAllString(base, "")
	if len(sanitized) < 3 {
		sanitized = "trader_" + sanitized
	}
	if len(sanitized) > 20 {
		sanitized = sanitized[:20]
	}

	// Add random suffix to avoid collision
	candidate := fmt.Sprintf("%s_%s", sanitized, uuid.NewString()[:6])
	if len(candidate) > 32 {
		candidate = candidate[:32]
	}

	return candidate
}
