// Package engine is the top-level orchestrator for the Liquidity Engine.
// It owns the single event loop goroutine that serialises all state mutations.
//
// State machine:
//
//	STARTING → SYNCING → RUNNING → PAUSED → RUNNING
//	                             ↗
//	                      DEGRADED (inventory skew, but still running)
//
// CONCURRENCY MODEL:
//   - Single goroutine (Run loop) owns all tracker and inventory mutations.
//   - Kafka consumer sends to e.events channel (unbuffered read, buffered channel).
//   - Ticker callbacks post events to e.events (no direct state mutation).
//   - All timeout checks happen inside the Run loop.
package engine

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/shopspring/decimal"
	"go.uber.org/zap"

	"tradedrift/services/liquidity-engine/internal/config"
	"tradedrift/services/liquidity-engine/internal/inventory"
	"tradedrift/services/liquidity-engine/internal/kafka"
	"tradedrift/services/liquidity-engine/internal/order"
	"tradedrift/services/liquidity-engine/internal/reconciler"
)


// EngineState is the lifecycle state of the LE engine.
type EngineState int

const (
	StateStarting  EngineState = iota
	StateSyncing               // discovering existing MM orders from Order Service
	StateRunning               // nominal operation
	StateDegraded              // running but inventory skew active
	StatePaused                // ME unresponsive or critical failure; will auto-recover
	StateStopped               // graceful shutdown complete
)

func (s EngineState) String() string {
	switch s {
	case StateStarting:
		return "STARTING"
	case StateSyncing:
		return "SYNCING"
	case StateRunning:
		return "RUNNING"
	case StateDegraded:
		return "DEGRADED"
	case StatePaused:
		return "PAUSED"
	case StateStopped:
		return "STOPPED"
	default:
		return "UNKNOWN"
	}
}

// event is the internal event type used by the event loop.
type eventKind int

const (
	evTrade          eventKind = iota
	evReconcileTick            // periodic reconcile timer fired
	evWalletTick               // periodic wallet refresh timer fired
	evPendingCheck             // periodic PENDING timeout check fired
	evCancellingCheck          // periodic CANCELLING timeout check fired
	evResyncTick               // periodic full resync from Order Service
)

type loopEvent struct {
	kind  eventKind
	trade kafka.TradeEvent
}

// EngineMetrics is the metrics interface the engine uses.
type EngineMetrics interface {
	reconciler.ReconcilerMetrics
	SetEngineState(state string)
	SetLevelCount(marketID, side string, count int)
	ObserveReconcileDuration(marketID string, ms float64)
	IncMELivenessTimeout(marketID string)
}

// Engine is the main Liquidity Engine orchestrator.
type Engine struct {
	cfg        *config.Config
	tracker    *order.Tracker
	inv        *inventory.Manager
	reconciler *reconciler.Reconciler
	producer   *kafka.Producer
	consumer   *kafka.Consumer
	metrics    EngineMetrics
	logger     *zap.Logger

	// events is the central channel all event sources feed into.
	// Buffered to absorb bursts without blocking Kafka consumer.
	events chan loopEvent

	// state is read-only outside the event loop (accessed via State()).
	state    EngineState
	stateMu  sync.RWMutex

	// consecutiveMETimeouts per market
	consecutiveMETimeouts map[string]int
}

// NewEngine creates a fully wired Engine. All dependencies must be non-nil.
func NewEngine(
	cfg *config.Config,
	tracker *order.Tracker,
	inv *inventory.Manager,
	rec *reconciler.Reconciler,
	producer *kafka.Producer,
	consumer *kafka.Consumer,
	metrics EngineMetrics,
	logger *zap.Logger,
) *Engine {
	return &Engine{
		cfg:                   cfg,
		tracker:               tracker,
		inv:                   inv,
		reconciler:            rec,
		producer:              producer,
		consumer:              consumer,
		metrics:               metrics,
		logger:                logger,
		events:                make(chan loopEvent, 256),
		state:                 StateStarting,
		consecutiveMETimeouts: make(map[string]int),
	}
}

// State returns the current engine state. Safe to call from any goroutine.
func (e *Engine) State() EngineState {
	e.stateMu.RLock()
	defer e.stateMu.RUnlock()
	return e.state
}

// setState updates the engine state. Must be called from the event loop only.
func (e *Engine) setState(s EngineState) {
	e.stateMu.Lock()
	e.state = s
	e.stateMu.Unlock()
	e.metrics.SetEngineState(s.String())
	e.logger.Info("engine state changed", zap.String("state", s.String()))
}

// Run starts the engine. Blocks until ctx is cancelled.
// This is the SINGLE goroutine that mutates tracker and inventory state.
func (e *Engine) Run(ctx context.Context) error {
	e.logger.Info("liquidity engine starting")
	e.setState(StateStarting)

	// Start Kafka consumer in background (only writes to events channel)
	go e.consumer.Run(ctx)

	// SYNCING: discover all existing MM orders from the Order Service
	e.setState(StateSyncing)
	if err := e.syncAllMarkets(ctx); err != nil {
		return fmt.Errorf("initial sync failed: %w", err)
	}

	// Start periodic tickers
	reconcileTicker := time.NewTicker(e.cfg.ReconcileInterval)
	walletTicker := time.NewTicker(e.cfg.WalletRefreshInterval)
	pendingTicker := time.NewTicker(e.cfg.PendingTimeout / 2)      // check at 2× rate
	cancellingTicker := time.NewTicker(e.cfg.CancellingTimeout / 2)
	resyncTicker := time.NewTicker(e.cfg.ReconcileInterval * 10)    // full resync every 10 reconciles
	defer reconcileTicker.Stop()
	defer walletTicker.Stop()
	defer pendingTicker.Stop()
	defer cancellingTicker.Stop()
	defer resyncTicker.Stop()

	// Start ticker pump goroutines (post events to channel, no state mutation)
	go e.pumpTicker(ctx, reconcileTicker.C, evReconcileTick)
	go e.pumpTicker(ctx, walletTicker.C, evWalletTick)
	go e.pumpTicker(ctx, pendingTicker.C, evPendingCheck)
	go e.pumpTicker(ctx, cancellingTicker.C, evCancellingCheck)
	go e.pumpTicker(ctx, resyncTicker.C, evResyncTick)

	e.setState(StateRunning)

	// Run initial reconcile immediately after sync
	e.runReconcileAll(ctx)

	// ── EVENT LOOP ───────────────────────────────────────────────────
	for {
		select {
		case <-ctx.Done():
			e.logger.Info("engine shutting down")
			e.setState(StateStopped)
			return nil

		case ev := <-e.events:
			switch ev.kind {
			case evTrade:
				e.handleTrade(ctx, ev.trade)

			case evReconcileTick:
				if e.state == StateRunning || e.state == StateDegraded {
					e.runReconcileAll(ctx)
				}

			case evWalletTick:
				e.handleWalletRefresh(ctx)

			case evPendingCheck:
				e.handlePendingCheck(ctx)

			case evCancellingCheck:
				if e.state == StateRunning || e.state == StateDegraded {
					e.handleCancellingCheck(ctx)
				}

			case evResyncTick:
				if e.state == StateRunning || e.state == StateDegraded {
					if err := e.syncAllMarkets(ctx); err != nil {
						e.logger.Warn("periodic full resync failed", zap.Error(err))
					}
				}
			}
		}
	}
}

// pumpTicker posts a tick event to the events channel when the ticker fires.
// It does NOT mutate any state — it is safe to run in a separate goroutine.
func (e *Engine) pumpTicker(ctx context.Context, ch <-chan time.Time, kind eventKind) {
	for {
		select {
		case <-ctx.Done():
			return
		case <-ch:
			select {
			case e.events <- loopEvent{kind: kind}:
			default:
				e.logger.Warn("event channel full — dropping tick event",
					zap.Int("event_kind", int(kind)))
			}
		}
	}
}

// handleTrade processes a TradeEvent from the Kafka consumer.
// Called from the event loop — safe to mutate tracker and inventory.
func (e *Engine) handleTrade(ctx context.Context, ev kafka.TradeEvent) {
	if ev.MMSide == "" {
		return // MM not involved — nothing to do
	}

	// Update in-memory inventory immediately (fast path before next wallet refresh)
	e.inv.ApplyTrade(ev)

	// Find the affected level(s) by looking for the order_id in the tracker
	// Trade fills may partially fill an order — the tracker will reflect new RemainingQty
	// after the next Order Service sync or via PENDING/RESTING promotion.
	// V1: targeted reconcile after a fill (debounced to avoid rapid churn)
	for _, o := range e.tracker.All(ev.MarketID) {
		if o.OrderID == ev.MakerOrderID || o.OrderID == ev.TakerOrderID {
			e.logger.Info("MM order involved in trade",
				zap.String("level_id", o.LevelID),
				zap.String("market_id", ev.MarketID),
				zap.String("mm_side", ev.MMSide),
				zap.String("quantity", ev.Quantity.String()))

			// Update tracker's remaining quantity from the trade fill
			if o.Status == order.StatusResting {
				newRemaining := o.RemainingQty.Sub(ev.Quantity)
				if newRemaining.IsNegative() {
					newRemaining = decimal.Zero
				}
				o.RemainingQty = newRemaining
				o.FilledQty = o.OriginalQty.Sub(newRemaining)
			}
			break
		}
	}

	// Reset consecutive ME timeouts — a trade execution confirms ME is alive
	e.consecutiveMETimeouts[ev.MarketID] = 0
}

// handleWalletRefresh fetches fresh balances from the Wallet Service.
// V1: stub — replace with actual gRPC call to Wallet Service GetBalances.
func (e *Engine) handleWalletRefresh(ctx context.Context) {
	// TODO V1: Implement gRPC call to Wallet Service
	// walletClient.GetBalances(ctx, account.WalletUUIDStr)
	// For now, check staleness and pause if exceeded
	if e.inv.IsStale(e.cfg.MaxBalanceStaleness) {
		e.logger.Error("wallet balance stale — pausing affected markets",
			zap.Duration("max_staleness", e.cfg.MaxBalanceStaleness))
		if e.state != StatePaused {
			e.setState(StatePaused)
		}
	}
}

// handlePendingCheck checks all PENDING orders across all markets.
// Uses CheckPendingTimeouts to detect ME liveness failures.
func (e *Engine) handlePendingCheck(ctx context.Context) {
	for _, mc := range e.cfg.Markets {
		consecutiveTimeouts := e.reconciler.CheckPendingTimeouts(ctx, mc.MarketID)

		if consecutiveTimeouts >= e.cfg.MELivenessThreshold {
			e.consecutiveMETimeouts[mc.MarketID]++
			e.metrics.IncMELivenessTimeout(mc.MarketID)
			e.logger.Error("ME liveness threshold exceeded — pausing",
				zap.String("market_id", mc.MarketID),
				zap.Int("consecutive_timeouts", consecutiveTimeouts))

			if e.state != StatePaused {
				e.setState(StatePaused)
			}
		}
	}
}

// handleCancellingCheck checks all CANCELLING orders for timeout and resolution.
func (e *Engine) handleCancellingCheck(ctx context.Context) {
	for _, mc := range e.cfg.Markets {
		e.reconciler.CheckCancellingTimeouts(ctx, mc.MarketID)
	}
}

// runReconcileAll runs a full reconcile cycle for all configured markets.
func (e *Engine) runReconcileAll(ctx context.Context) {
	// Check inventory staleness before reconciling
	if e.inv.IsStale(e.cfg.MaxBalanceStaleness) {
		e.logger.Warn("skipping reconcile — inventory is stale")
		return
	}

	allMarkets := make([]string, len(e.cfg.Markets))
	for i, m := range e.cfg.Markets {
		allMarkets[i] = m.MarketID
	}

	// Compute shared USDT effective available (bid side, all markets)
	effectiveQuote := e.inv.EffectiveAvailableQuote(allMarkets)

	isDegraded := false

	for _, mc := range e.cfg.Markets {
		start := time.Now()

		effectiveBase := e.inv.EffectiveAvailableBase(mc.MarketID)
		skew := inventory.ComputeSkew(&mc, effectiveBase, effectiveQuote, e.logger)

		if skew.BaseTier != inventory.TierNormal || skew.QuoteTier != inventory.TierNormal {
			isDegraded = true
		}

		e.metrics.SetLevelCount(mc.MarketID, "BUY", skew.BidCount)
		e.metrics.SetLevelCount(mc.MarketID, "SELL", skew.AskCount)

		cmds, err := e.reconciler.ReconcileMarket(ctx, mc.MarketID, skew.BidCount, skew.AskCount)
		if err != nil {
			e.logger.Error("reconcile failed",
				zap.String("market_id", mc.MarketID),
				zap.Error(err))
		}

		elapsed := time.Since(start).Milliseconds()
		e.metrics.ObserveReconcileDuration(mc.MarketID, float64(elapsed))

		if cmds > 0 {
			e.logger.Info("reconcile complete",
				zap.String("market_id", mc.MarketID),
				zap.Int("commands_published", cmds),
				zap.Int64("duration_ms", elapsed))
		}
	}

	// Update degraded state based on current skew
	if isDegraded && e.state == StateRunning {
		e.setState(StateDegraded)
	} else if !isDegraded && e.state == StateDegraded {
		e.setState(StateRunning)
	}
}

// syncAllMarkets calls ListMMOrders for all markets and populates the tracker.
// This is the startup SYNCING step and the periodic full resync.
func (e *Engine) syncAllMarkets(ctx context.Context) error {
	for _, mc := range e.cfg.Markets {
		if err := e.reconciler.SyncFromOrderService(ctx, mc.MarketID); err != nil {
			return fmt.Errorf("sync %s: %w", mc.MarketID, err)
		}
	}
	return nil
}

// ReadyBids returns the number of RESTING bid orders across all markets.
// Used by /readyz endpoint.
func (e *Engine) ReadyBids(marketID string) int {
	return e.tracker.ActiveCount(marketID, "BUY")
}

// ReadyAsks returns the number of RESTING ask orders across all markets.
func (e *Engine) ReadyAsks(marketID string) int {
	return e.tracker.ActiveCount(marketID, "SELL")
}

// IsReady returns true if all markets have at least MinReadyBids and MinReadyAsks resting.
func (e *Engine) IsReady() bool {
	for _, mc := range e.cfg.Markets {
		if e.tracker.ActiveCount(mc.MarketID, "BUY") < e.cfg.MinReadyBids {
			return false
		}
		if e.tracker.ActiveCount(mc.MarketID, "SELL") < e.cfg.MinReadyAsks {
			return false
		}
	}
	return true
}
