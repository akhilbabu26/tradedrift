package client

import (
	"context"
	"fmt"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"

	authv1 "tradedrift/platform/api/gen/auth/v1"
)

// AuthClient wraps the Auth gRPC client with correlation metadata injection.
type AuthClient struct {
	client authv1.AuthServiceClient
	conn   *grpc.ClientConn
}

// NewAuthClient creates a non-blocking gRPC connection to the Auth service.
func NewAuthClient(grpcAddr string) (*AuthClient, error) {
	conn, err := grpc.Dial(grpcAddr,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		return nil, fmt.Errorf("auth_client: dial %s: %w", grpcAddr, err)
	}
	return &AuthClient{client: authv1.NewAuthServiceClient(conn), conn: conn}, nil
}

// Close releases the underlying gRPC connection.
func (c *AuthClient) Close() error {
	if c.conn != nil {
		return c.conn.Close()
	}
	return nil
}

// InvalidateUserSessions calls the Auth service's internal InvalidateUserSessions RPC
// to revoke all active sessions for the given user. Injects request_id and operation_id
// into gRPC metadata for end-to-end tracing. Times out after 10 seconds.
func (c *AuthClient) InvalidateUserSessions(ctx context.Context, userID, reason, requestID, operationID string) error {
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	// Propagate distributed tracing headers into gRPC metadata.
	md := metadata.Pairs(
		"x-request-id", requestID,
		"x-operation-id", operationID,
	)
	ctx = metadata.NewOutgoingContext(ctx, md)

	resp, err := c.client.InvalidateUserSessions(ctx, &authv1.InvalidateUserSessionsRequest{
		UserId: userID,
		Reason: reason,
	})
	if err != nil {
		return fmt.Errorf("auth_client: InvalidateUserSessions: %w", err)
	}
	if !resp.Success {
		return fmt.Errorf("auth_client: InvalidateUserSessions: auth service returned success=false")
	}
	return nil
}
