package postgres

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5/pgxpool"

	"tradedrift/services/admin/internal/domain"
	"tradedrift/services/admin/internal/repository"
)

type outboxRepo struct {
	db *pgxpool.Pool
}

var _ repository.OutboxRepository = (*outboxRepo)(nil)

// NewOutboxRepo constructs an OutboxRepository backed by PostgreSQL.
func NewOutboxRepo(db *pgxpool.Pool) repository.OutboxRepository {
	return &outboxRepo{db: db}
}

// Insert writes an outbox event. Called inside TxManager's transaction.
func (r *outboxRepo) Insert(ctx context.Context, event *domain.OutboxEvent) error {
	query := `
		INSERT INTO admin_outbox (id, operation_id, topic, payload, published, created_at)
		VALUES ($1, $2, $3, $4, FALSE, $5)
	`
	_, err := r.db.Exec(ctx, query,
		event.ID,
		event.OperationID,
		event.Topic,
		event.Payload,
		event.CreatedAt,
	)
	if err != nil {
		return fmt.Errorf("outbox_repo: insert: %w", err)
	}
	return nil
}

// FetchUnpublished returns up to limit unpublished events using SKIP LOCKED
// so concurrent outbox publishers do not process the same event.
func (r *outboxRepo) FetchUnpublished(ctx context.Context, limit int) ([]*domain.OutboxEvent, error) {
	query := `
		SELECT id, operation_id, topic, payload, published, created_at
		FROM admin_outbox
		WHERE published = FALSE
		ORDER BY created_at ASC
		LIMIT $1
		FOR UPDATE SKIP LOCKED
	`
	rows, err := r.db.Query(ctx, query, limit)
	if err != nil {
		return nil, fmt.Errorf("outbox_repo: fetch unpublished: %w", err)
	}
	defer rows.Close()

	var events []*domain.OutboxEvent
	for rows.Next() {
		var e domain.OutboxEvent
		if err := rows.Scan(&e.ID, &e.OperationID, &e.Topic, &e.Payload, &e.Published, &e.CreatedAt); err != nil {
			return nil, fmt.Errorf("outbox_repo: scan: %w", err)
		}
		events = append(events, &e)
	}
	return events, rows.Err()
}

// MarkPublished marks an event as published after successful Kafka delivery.
func (r *outboxRepo) MarkPublished(ctx context.Context, id string) error {
	query := `
		UPDATE admin_outbox
		SET published    = TRUE,
		    published_at = NOW()
		WHERE id = $1
	`
	_, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("outbox_repo: mark published: %w", err)
	}
	return nil
}
