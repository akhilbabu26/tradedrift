// Package inventory manages the MM-001 balance state and provides
// effective available inventory calculations for the LE's skew decisions.
//
// The LE bypasses Wallet Service's ReserveFunds mechanism — MM orders are
// not reflected in wallet.reserved_balance. The Manager computes its own
// effective_available by subtracting resting order commitments.
//
// All methods must be called from the engine's single event loop goroutine.
package inventory

import (
	"context"
	"fmt"
	"time"

	"github.com/shopspring/decimal"
	"go.uber.org/zap"

	"tradedrift/services/liquidity-engine/internal/kafka"
	"tradedrift/services/liquidity-engine/internal/order"
)

// AssetBalance holds the authoritative balance for one asset from the Wallet Service.
type AssetBalance struct {
	Asset            string
	AvailableBalance decimal.Decimal
	// reserved_balance is intentionally NOT stored — LE bypasses ReserveFunds
	// and MM orders are never in wallet.reserved_balance
}

// Manager tracks authoritative wallet balances and applies trade fills
// to maintain a fast view of effective available inventory.
//
// Effective available = wallet.available_balance − Σ(RemainingQty of resting commitments)
// This is computed on demand from the tracker (not cached) to stay correct after fills.
type Manager struct {
	// authBalances holds the last-refreshed balance from the Wallet Service.
	// Key: asset code ("BTC", "ETH", "SOL", "USDT")
	authBalances map[string]decimal.Decimal

	// lastRefresh is when authBalances was last successfully updated from Wallet Service.
	lastRefresh time.Time

	// tracker is used to compute committed inventory (resting order quantities).
	tracker *order.Tracker

	logger *zap.Logger
}

// NewManager creates a new inventory Manager. Call RefreshFromWallet before use.
func NewManager(tracker *order.Tracker, logger *zap.Logger) *Manager {
	return &Manager{
		authBalances: make(map[string]decimal.Decimal),
		tracker:      tracker,
		logger:       logger,
	}
}

// RefreshFromWallet updates authoritative balances from the Wallet Service response.
// Call this at startup and every WalletRefreshInterval.
// balances maps asset code → available_balance.
func (m *Manager) RefreshFromWallet(balances map[string]decimal.Decimal) {
	for asset, bal := range balances {
		m.authBalances[asset] = bal
		m.logger.Info("wallet balance refreshed",
			zap.String("asset", asset),
			zap.String("balance", bal.String()))
	}
	m.lastRefresh = time.Now()
}

// ApplyTrade updates the in-memory balance view based on a trade execution.
// This provides a fast update before the next WalletRefreshInterval.
//
// For MM SELL (ask filled): base decreases, quote increases
// For MM BUY  (bid filled): quote decreases, base increases
func (m *Manager) ApplyTrade(event kafka.TradeEvent) {
	if event.MMSide == "" {
		return // MM not involved in this trade
	}

	qty := event.Quantity
	quoteValue := event.Quantity.Mul(event.Price)

	switch event.MMSide {
	case "SELL":
		// MM sold base asset (ask was filled) → base decreases, quote increases
		if bal, ok := m.authBalances[baseAsset(event.MarketID)]; ok {
			m.authBalances[baseAsset(event.MarketID)] = maxZero(bal.Sub(qty))
		}
		if bal, ok := m.authBalances["USDT"]; ok {
			m.authBalances["USDT"] = bal.Add(quoteValue)
		}
		m.logger.Info("inventory: MM SELL filled",
			zap.String("market_id", event.MarketID),
			zap.String("qty", qty.String()),
			zap.String("quote_received", quoteValue.String()))

	case "BUY":
		// MM bought base asset (bid was filled) → quote decreases, base increases
		if bal, ok := m.authBalances["USDT"]; ok {
			m.authBalances["USDT"] = maxZero(bal.Sub(quoteValue))
		}
		if bal, ok := m.authBalances[baseAsset(event.MarketID)]; ok {
			m.authBalances[baseAsset(event.MarketID)] = bal.Add(qty)
		}
		m.logger.Info("inventory: MM BUY filled",
			zap.String("market_id", event.MarketID),
			zap.String("qty", qty.String()),
			zap.String("quote_spent", quoteValue.String()))
	}
}

// EffectiveAvailableBase returns the effective available base asset for a market.
// effective_base = wallet.available_balance[base] − committed_base
// committed_base = Σ(RemainingQty) of all RESTING + PENDING SELL orders for this market
func (m *Manager) EffectiveAvailableBase(marketID string) decimal.Decimal {
	base := baseAsset(marketID)
	walletBal, ok := m.authBalances[base]
	if !ok {
		return decimal.Zero
	}
	committed := m.tracker.CommittedBase(marketID)
	return maxZero(walletBal.Sub(committed))
}

// EffectiveAvailableQuote returns the effective available USDT for bid-side quoting.
// effective_quote = wallet.available_balance[USDT] − committed_quote_across_all_markets
// committed_quote = Σ(RemainingQty × Price) for all RESTING + PENDING BUY orders
//
// Note: USDT commitment is calculated across ALL markets (BTC + ETH + SOL bids all use USDT).
func (m *Manager) EffectiveAvailableQuote(markets []string) decimal.Decimal {
	walletBal, ok := m.authBalances["USDT"]
	if !ok {
		return decimal.Zero
	}
	totalCommitted := decimal.Zero
	for _, marketID := range markets {
		totalCommitted = totalCommitted.Add(m.tracker.CommittedQuote(marketID))
	}
	return maxZero(walletBal.Sub(totalCommitted))
}

// LastRefresh returns when the Wallet Service balance was last successfully fetched.
func (m *Manager) LastRefresh() time.Time {
	return m.lastRefresh
}

// IsStale returns true if the wallet balance has not been refreshed within the given threshold.
func (m *Manager) IsStale(maxStaleness time.Duration) bool {
	if m.lastRefresh.IsZero() {
		return true // never refreshed
	}
	return time.Since(m.lastRefresh) > maxStaleness
}

// WalletBalanceFor returns the raw authoritative balance for an asset.
// Returns (Zero, false) if the asset is not tracked.
func (m *Manager) WalletBalanceFor(asset string) (decimal.Decimal, bool) {
	bal, ok := m.authBalances[asset]
	return bal, ok
}

// ValidateMMAccount is called at startup to confirm MM-001 has all expected assets.
// Returns an error if any required asset wallet is missing.
func ValidateMMAccount(ctx context.Context, balances map[string]decimal.Decimal) error {
	required := []string{"BTC", "ETH", "SOL", "USDT"}
	for _, asset := range required {
		if _, ok := balances[asset]; !ok {
			return fmt.Errorf("MM-001 wallet missing required asset %q — run migration 00003_seed_mm001_wallet.sql", asset)
		}
	}
	return nil
}

// baseAsset extracts the base asset code from a market ID.
// "BTC-USDT" → "BTC", "ETH-USDT" → "ETH", "SOL-USDT" → "SOL"
func baseAsset(marketID string) string {
	for i := 0; i < len(marketID); i++ {
		if marketID[i] == '-' {
			return marketID[:i]
		}
	}
	return marketID
}

// maxZero returns d if d > 0, else Zero. Prevents negative effective balances.
func maxZero(d decimal.Decimal) decimal.Decimal {
	if d.IsNegative() {
		return decimal.Zero
	}
	return d
}
