package ws

import (
	"encoding/json"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	"go.uber.org/zap"
)

const (
	writeWait      = 10 * time.Second
	pongWait       = 60 * time.Second
	pingPeriod     = (pongWait * 9) / 10
	maxMessageSize = 512 * 1024 // 512 KB
	sendBufferSize = 256
	maxSubLimit    = 50
)

// Client represents a single connected WebSocket client session.
type Client struct {
	hub        *Hub
	conn       *websocket.Conn
	send       chan []byte
	userID     string // authenticated user ID (empty for anonymous)
	logger     *zap.Logger
	subsMu     sync.RWMutex
	subs       map[string]bool
	closed     bool
	closedMu   sync.Mutex
	slowWarned bool
}

// NewClient creates a new Client instance.
func NewClient(hub *Hub, conn *websocket.Conn, userID string, logger *zap.Logger) *Client {
	return &Client{
		hub:    hub,
		conn:   conn,
		send:   make(chan []byte, sendBufferSize),
		userID: userID,
		logger: logger,
		subs:   make(map[string]bool),
	}
}

// UserID returns the authenticated user ID of this connection.
func (c *Client) UserID() string {
	return c.userID
}

// HasSubscription checks if the client is subscribed to a stream.
func (c *Client) HasSubscription(stream string) bool {
	c.subsMu.RLock()
	defer c.subsMu.RUnlock()
	return c.subs[stream]
}

// AddSubscription registers a stream subscription.
func (c *Client) AddSubscription(stream string) bool {
	c.subsMu.Lock()
	defer c.subsMu.Unlock()
	if len(c.subs) >= maxSubLimit {
		return false
	}
	c.subs[stream] = true
	return true
}

// RemoveSubscription unregisters a stream subscription.
func (c *Client) RemoveSubscription(stream string) {
	c.subsMu.Lock()
	defer c.subsMu.Unlock()
	delete(c.subs, stream)
}

// Subscriptions returns a copy of all active subscriptions for this client.
func (c *Client) Subscriptions() []string {
	c.subsMu.RLock()
	defer c.subsMu.RUnlock()
	list := make([]string, 0, len(c.subs))
	for s := range c.subs {
		list = append(list, s)
	}
	return list
}

// Send enqueues a message for delivery, strictly enforcing the Stream-Specific Backpressure Matrix.
func (c *Client) Send(streamType string, msg []byte) bool {
	c.closedMu.Lock()
	if c.closed {
		c.closedMu.Unlock()
		return false
	}
	c.closedMu.Unlock()

	select {
	case c.send <- msg:
		return true
	default:
		// Channel buffer (256) is full: apply backpressure policy based on stream type
		switch streamType {
		case StreamTypeOrderBook, StreamTypeTicker:
			// Non-critical high-frequency updates: drop stale snapshot
			c.hub.RecordMessageDropped()
			c.logger.Debug("Dropping stale snapshot due to client backpressure",
				zap.String("stream_type", streamType),
				zap.String("user_id", c.userID),
			)
			return false

		case StreamTypeTrades, StreamTypeNotification:
			// Critical execution feed / private notification: DO NOT silently drop
			// Disconnect the slow client to maintain stream integrity
			c.hub.RecordSlowClientDisconnect()
			c.logger.Warn("Disconnecting slow client to prevent message loss on execution stream",
				zap.String("stream_type", streamType),
				zap.String("user_id", c.userID),
			)
			c.Close()
			return false

		default:
			c.hub.RecordMessageDropped()
			return false
		}
	}
}

// Close gracefully closes the client connection.
func (c *Client) Close() {
	c.closedMu.Lock()
	if c.closed {
		c.closedMu.Unlock()
		return
	}
	c.closed = true
	c.closedMu.Unlock()

	if c.conn != nil {
		_ = c.conn.Close()
	}
	c.hub.Unregister(c)
}

// ReadPump listens for incoming frames from the WebSocket connection.
func (c *Client) ReadPump() {
	defer c.Close()

	c.conn.SetReadLimit(maxMessageSize)
	_ = c.conn.SetReadDeadline(time.Now().Add(pongWait))
	c.conn.SetPongHandler(func(string) error {
		_ = c.conn.SetReadDeadline(time.Now().Add(pongWait))
		return nil
	})

	for {
		_, message, err := c.conn.ReadMessage()
		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure, websocket.CloseNormalClosure) {
				c.logger.Debug("WebSocket read error", zap.Error(err))
			}
			break
		}

		var frame InboundFrame
		if err := json.Unmarshal(message, &frame); err != nil {
			c.SendControlError("MALFORMED_FRAME", "invalid json payload")
			continue
		}

		c.hub.HandleClientFrame(c, frame)
	}
}

// WritePump writes queued outbound messages to the WebSocket connection.
func (c *Client) WritePump() {
	ticker := time.NewTicker(pingPeriod)
	defer func() {
		ticker.Stop()
		_ = c.conn.Close()
	}()

	for {
		select {
		case message, ok := <-c.send:
			_ = c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if !ok {
				_ = c.conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}

			w, err := c.conn.NextWriter(websocket.TextMessage)
			if err != nil {
				return
			}
			if _, err := w.Write(message); err != nil {
				return
			}

			// Batch any pending messages in buffer into single flush
			n := len(c.send)
			for i := 0; i < n; i++ {
				_, _ = w.Write([]byte{'\n'})
				_, _ = w.Write(<-c.send)
			}

			if err := w.Close(); err != nil {
				return
			}

		case <-ticker.C:
			_ = c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}

// SendControlError sends a structured error frame to the client.
func (c *Client) SendControlError(code, message string) {
	evt := OutboundEvent{
		Event:   "error",
		Code:    code,
		Message: message,
	}
	bytes, _ := json.Marshal(evt)
	c.Send(StreamTypeControl, bytes)
}

// SendPong sends a pong response frame.
func (c *Client) SendPong() {
	evt := OutboundEvent{Event: "pong"}
	bytes, _ := json.Marshal(evt)
	c.Send(StreamTypeControl, bytes)
}
