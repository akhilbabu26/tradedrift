package repository

import (
	"context"
	"time"

	"tradedrift/services/admin/internal/domain"
)

// AuditRepository writes append-only audit records.
// PostgreSQL triggers prevent any UPDATE or DELETE on the underlying table.
type AuditRepository interface {
	Insert(ctx context.Context, log *domain.AuditLog) error
}

// OperationsRepository manages the admin_operations idempotency store.
type OperationsRepository interface {
	// GetByIdempotencyKey returns an existing operation for (adminID, key), or nil if none.
	GetByIdempotencyKey(ctx context.Context, adminID, key string) (*domain.AdminOperation, error)
	Insert(ctx context.Context, op *domain.AdminOperation) error
	UpdateStatus(ctx context.Context, id string, status domain.OperationStatus, responseBody []byte) error
}

// OutboxRepository manages the transactional outbox for Kafka events.
type OutboxRepository interface {
	Insert(ctx context.Context, event *domain.OutboxEvent) error
	// FetchUnpublished returns up to limit unpublished events using SELECT ... FOR UPDATE SKIP LOCKED.
	FetchUnpublished(ctx context.Context, limit int) ([]*domain.OutboxEvent, error)
	MarkPublished(ctx context.Context, id string) error
}

// SagaRepository manages admin_saga_tasks for the Auth invalidation retry engine.
type SagaRepository interface {
	Insert(ctx context.Context, task *domain.SagaTask) error
	// FetchDue returns tasks ready for a retry attempt (status PENDING/RETRYING, next_attempt_at <= now).
	// Uses SELECT ... FOR UPDATE SKIP LOCKED to prevent double-processing by concurrent workers.
	FetchDue(ctx context.Context, workerToken string, limit int) ([]*domain.SagaTask, error)
	UpdateRetry(ctx context.Context, id string, nextAttemptAt time.Time, attemptCount int, lastError string) error
	MarkCompleted(ctx context.Context, id string) error
	MarkExhausted(ctx context.Context, id string, lastError string) error
}

// TxManager executes the admin mutation as a single atomic database transaction:
// INSERT audit_log + INSERT/UPDATE admin_operations + INSERT outbox + INSERT saga_task (if needed).
type TxManager interface {
	ExecAdminOperationTx(ctx context.Context, req AdminOperationTxRequest) (*AdminOperationTxResult, error)
}

// AdminOperationTxRequest bundles everything needed for an atomic admin mutation.
type AdminOperationTxRequest struct {
	Operation   *domain.AdminOperation
	AuditLog    *domain.AuditLog
	OutboxEvent *domain.OutboxEvent
	SagaTask    *domain.SagaTask // nil if no saga needed (e.g. wallet freeze, market halt)
}

// AdminOperationTxResult is returned after a successful commit.
type AdminOperationTxResult struct {
	Operation *domain.AdminOperation
}
