package ws

import (
	"testing"
	"time"

	"go.uber.org/zap"
)

// mockSnapshotProvider implements SnapshotProvider for unit tests.
type mockSnapshotProvider struct {
	depthCalls  int
	tickerCalls int
}

func (m *mockSnapshotProvider) GetImmediateOrderBook(marketID string) (*OrderBookDepthPayload, error) {
	m.depthCalls++
	return &OrderBookDepthPayload{
		MarketID:  marketID,
		Bids:      [][2]string{{"64000.00", "1.0"}},
		Asks:      [][2]string{{"64100.00", "1.5"}},
		Timestamp: time.Now(),
	}, nil
}

func (m *mockSnapshotProvider) GetImmediateTicker(marketID string) (*TickerPayload, error) {
	m.tickerCalls++
	return &TickerPayload{
		MarketID:  marketID,
		LastPrice: "64050.00",
	}, nil
}

func TestHub_OnDemandMarketTracking(t *testing.T) {
	logger := zap.NewNop()
	mockProvider := &mockSnapshotProvider{}
	hub := NewHub(logger, mockProvider)

	client := &Client{
		hub:    hub,
		send:   make(chan []byte, 10),
		userID: "user-123",
		logger: logger,
		subs:   make(map[string]bool),
	}
	hub.Register(client)

	// Initially zero active markets
	if len(hub.GetActiveMarketIDs()) != 0 {
		t.Fatalf("expected 0 active markets, got %d", len(hub.GetActiveMarketIDs()))
	}

	// Subscribe to BTC-USDT orderbook
	hub.HandleClientFrame(client, InboundFrame{
		Event:   "subscribe",
		Streams: []string{"market:orderbook:BTC-USDT"},
	})

	active := hub.GetActiveMarketIDs()
	if len(active) != 1 || active[0] != "BTC-USDT" {
		t.Fatalf("expected ['BTC-USDT'] active market, got %v", active)
	}

	// Immediate snapshot should have been invoked
	if mockProvider.depthCalls != 1 {
		t.Fatalf("expected 1 immediate depth call, got %d", mockProvider.depthCalls)
	}

	// Unsubscribe
	hub.HandleClientFrame(client, InboundFrame{
		Event:   "unsubscribe",
		Streams: []string{"market:orderbook:BTC-USDT"},
	})

	if len(hub.GetActiveMarketIDs()) != 0 {
		t.Fatalf("expected 0 active markets after unsubscribe, got %d", len(hub.GetActiveMarketIDs()))
	}
}

func TestHub_PrivateChannelAuthorization(t *testing.T) {
	logger := zap.NewNop()
	hub := NewHub(logger, &mockSnapshotProvider{})

	// Anonymous client
	anonClient := &Client{
		hub:    hub,
		send:   make(chan []byte, 10),
		userID: "",
		logger: logger,
		subs:   make(map[string]bool),
	}
	hub.Register(anonClient)

	hub.HandleClientFrame(anonClient, InboundFrame{
		Event:   "subscribe",
		Streams: []string{"user:notifications:user-123"},
	})

	if anonClient.HasSubscription("user:notifications:user-123") {
		t.Fatal("anonymous client should NOT be allowed to subscribe to private notifications")
	}

	// Authenticated client with wrong ID
	otherClient := &Client{
		hub:    hub,
		send:   make(chan []byte, 10),
		userID: "user-456",
		logger: logger,
		subs:   make(map[string]bool),
	}
	hub.Register(otherClient)

	hub.HandleClientFrame(otherClient, InboundFrame{
		Event:   "subscribe",
		Streams: []string{"user:notifications:user-123"},
	})

	if otherClient.HasSubscription("user:notifications:user-123") {
		t.Fatal("client with mismatched user_id should NOT be allowed to subscribe to other user's stream")
	}

	// Authenticated client with matching ID
	validClient := &Client{
		hub:    hub,
		send:   make(chan []byte, 10),
		userID: "user-123",
		logger: logger,
		subs:   make(map[string]bool),
	}
	hub.Register(validClient)

	hub.HandleClientFrame(validClient, InboundFrame{
		Event:   "subscribe",
		Streams: []string{"user:notifications:user-123"},
	})

	if !validClient.HasSubscription("user:notifications:user-123") {
		t.Fatal("client with matching user_id SHOULD be allowed to subscribe to private stream")
	}
}

func TestClient_BackpressureMatrix(t *testing.T) {
	logger := zap.NewNop()
	hub := NewHub(logger, &mockSnapshotProvider{})

	client := &Client{
		hub:    hub,
		send:   make(chan []byte, 1), // Buffer size 1 for easy saturation
		userID: "user-123",
		logger: logger,
		subs:   make(map[string]bool),
	}
	hub.Register(client)

	// Fill buffer
	client.Send(StreamTypeOrderBook, []byte("msg1"))

	// 1. OrderBook Backpressure -> Should drop stale snapshot without closing connection
	dropped := !client.Send(StreamTypeOrderBook, []byte("msg2"))
	if !dropped {
		t.Fatal("expected orderbook update to be dropped when buffer is saturated")
	}
	if client.closed {
		t.Fatal("client should NOT be closed when orderbook snapshot is dropped")
	}
	if hub.MessagesDroppedTotal() == 0 {
		t.Fatal("expected dropped messages metric to increment")
	}

	// 2. Trades Backpressure -> Should disconnect slow client to prevent silent trade loss
	client.Send(StreamTypeTrades, []byte("trade1"))
	if !client.closed {
		t.Fatal("expected slow client to be disconnected when trade execution stream is saturated")
	}
	if hub.SlowClientsTotal() == 0 {
		t.Fatal("expected slow clients metric to increment")
	}
}
