package order

import (
	"testing"

	"github.com/shopspring/decimal"

	"tradedrift/services/liquidity-engine/internal/config"
	"tradedrift/services/liquidity-engine/internal/pricing"
)

const testMarket = "BTC-USDT"

func testCfg() *config.MarketConfig {
	return &config.MarketConfig{
		MarketID:     testMarket,
		MinOrderSize: decimal.RequireFromString("0.00001"),
		TickSize:     decimal.RequireFromString("0.01"),
		LotSize:      decimal.RequireFromString("0.00001"),
	}
}

func price(s string) decimal.Decimal { return decimal.RequireFromString(s) }
func qty(s string) decimal.Decimal   { return decimal.RequireFromString(s) }

// desiredLevel is a helper for building test desired levels.
func desiredLevel(id, side, p, q string) pricing.PriceLevel {
	return pricing.PriceLevel{
		LevelID:  id,
		MarketID: testMarket,
		Side:     side,
		Price:    price(p),
		Quantity: qty(q),
	}
}

// restingOrder adds a RESTING order to the tracker and returns the tracker.
func addResting(t *Tracker, id, side, p, remaining string) *Tracker {
	t.orders[id] = &LiveOrder{
		LevelID:       id,
		ClientOrderID: id + "-G001",
		OrderID:       "order-uuid-" + id,
		MarketID:      testMarket,
		Side:          side,
		Price:         price(p),
		OriginalQty:   qty(remaining),
		RemainingQty:  qty(remaining),
		FilledQty:     decimal.Zero,
		Status:        StatusResting,
	}
	return t
}

// TestDiff_EmptyBothSides: no desired, no actual → no entries.
func TestDiff_EmptyBothSides(t *testing.T) {
	tracker := NewTracker()
	entries := Diff(nil, tracker, testMarket, testCfg())
	if len(entries) != 0 {
		t.Errorf("expected 0 entries, got %d", len(entries))
	}
}

// TestDiff_AllDesiredMissing: 12 desired, tracker empty → 12 CREATE.
func TestDiff_AllDesiredMissing(t *testing.T) {
	tracker := NewTracker()
	mc := testCfg()
	mc.ReferencePrice = price("96450.00")
	mc.SpreadBps = 4

	cfg := &config.MarketConfig{
		MarketID:        testMarket,
		TickSize:        decimal.RequireFromString("0.01"),
		LotSize:         decimal.RequireFromString("0.00001"),
		SpreadBps:       4,
		ReferencePrice:  price("96450.00"),
		LevelCount:      12,
		MinOrderSize:    decimal.RequireFromString("0.00001"),
		MaxDeviationPct: price("15"),
	}
	desired := pricing.GenerateLadder(cfg, 12, 12)

	entries := Diff(desired, tracker, testMarket, cfg)
	if len(entries) != 24 {
		t.Fatalf("expected 24 CREATE entries, got %d", len(entries))
	}
	for _, e := range entries {
		if e.Action != DiffCreate {
			t.Errorf("expected DiffCreate, got %d for %s", e.Action, e.LevelID)
		}
	}
}

// TestDiff_ExactMatch: desired == actual → 0 entries (ZERO commands).
func TestDiff_ExactMatch(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96487.00", "0.85000"),
		desiredLevel("MM-BTC-USDT-BID-01", "BUY", "96411.00", "0.85000"),
	}
	// Populate tracker to match desired exactly
	addResting(tracker, "MM-BTC-USDT-ASK-01", "SELL", "96487.00", "0.85000")
	addResting(tracker, "MM-BTC-USDT-BID-01", "BUY", "96411.00", "0.85000")

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 0 {
		t.Errorf("exact match should produce 0 entries, got %d: %+v", len(entries), entries)
	}
}

// TestDiff_PriceMismatch: resting order has stale price → 1 CORRECT.
func TestDiff_PriceMismatch(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000"),
	}
	// Tracker has different price
	addResting(tracker, "MM-BTC-USDT-ASK-01", "SELL", "96450.00", "0.85000")

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 1 {
		t.Fatalf("expected 1 CORRECT, got %d: %+v", len(entries), entries)
	}
	if entries[0].Action != DiffCorrect {
		t.Errorf("expected DiffCorrect, got %d", entries[0].Action)
	}
}

// TestDiff_QuantityExhausted: remaining < MinOrderSize → CORRECT.
func TestDiff_QuantityExhausted(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000"),
	}
	// Resting order with remaining below MinOrderSize
	tracker.orders["MM-BTC-USDT-ASK-01"] = &LiveOrder{
		LevelID:       "MM-BTC-USDT-ASK-01",
		ClientOrderID: "MM-BTC-USDT-ASK-01-G001",
		OrderID:       "order-uuid-1",
		MarketID:      testMarket,
		Side:          "SELL",
		Price:         price("96500.00"),  // price matches — correction is due to qty only
		OriginalQty:   qty("0.85000"),
		RemainingQty:  qty("0.000005"),   // below MinOrderSize (0.00001)
		Status:        StatusResting,
	}

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 1 {
		t.Fatalf("expected 1 CORRECT for exhausted qty, got %d: %+v", len(entries), entries)
	}
	if entries[0].Action != DiffCorrect {
		t.Errorf("expected DiffCorrect, got %d", entries[0].Action)
	}
}

// TestDiff_ExtraResting: RESTING order not in desired → CANCEL.
func TestDiff_ExtraResting(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000"),
	}
	addResting(tracker, "MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000")
	addResting(tracker, "MM-BTC-USDT-ASK-02", "SELL", "96650.00", "0.85000") // extra

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 1 {
		t.Fatalf("expected 1 CANCEL for extra RESTING, got %d", len(entries))
	}
	if entries[0].Action != DiffCancel {
		t.Errorf("expected DiffCancel, got %d", entries[0].Action)
	}
	if entries[0].LevelID != "MM-BTC-USDT-ASK-02" {
		t.Errorf("wrong level cancelled: %s", entries[0].LevelID)
	}
}

// TestDiff_PendingBlocksCreate: desired level with PENDING tracker entry → no CREATE.
func TestDiff_PendingBlocksCreate(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000"),
	}
	// Level is in PENDING — knownSet blocks CREATE
	tracker.orders["MM-BTC-USDT-ASK-01"] = &LiveOrder{
		LevelID:  "MM-BTC-USDT-ASK-01",
		MarketID: testMarket,
		Status:   StatusPending,
	}

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 0 {
		t.Errorf("PENDING should block CREATE, got %d entries: %+v", len(entries), entries)
	}
}

// TestDiff_CancellingBlocksCreate: CANCELLING entry blocks both CREATE and CANCEL.
func TestDiff_CancellingBlocksCreate(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000"),
	}
	tracker.orders["MM-BTC-USDT-ASK-01"] = &LiveOrder{
		LevelID:  "MM-BTC-USDT-ASK-01",
		MarketID: testMarket,
		Status:   StatusCancelling,
	}

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 0 {
		t.Errorf("CANCELLING should produce 0 entries, got %d: %+v", len(entries), entries)
	}
}

// TestDiff_StaleBlocksCreate: STALE entry blocks CREATE (prevents duplicate in book).
func TestDiff_StaleBlocksCreate(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000"),
	}
	tracker.orders["MM-BTC-USDT-ASK-01"] = &LiveOrder{
		LevelID:  "MM-BTC-USDT-ASK-01",
		MarketID: testMarket,
		Status:   StatusStale,
	}

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 0 {
		t.Errorf("STALE should block CREATE, got %d entries: %+v", len(entries), entries)
	}
}

// TestDiff_CORRECTCarriesDesiredLevel: DiffCorrect entry has DesiredLevel set.
func TestDiff_CORRECTCarriesDesiredLevel(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96999.00", "0.85000"),
	}
	addResting(tracker, "MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000")

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 1 || entries[0].Action != DiffCorrect {
		t.Fatal("expected 1 DiffCorrect")
	}
	if entries[0].DesiredLevel == nil {
		t.Error("DiffCorrect must carry DesiredLevel for replacement order")
	}
	if !entries[0].DesiredLevel.Price.Equal(price("96999.00")) {
		t.Errorf("wrong desired price: %s", entries[0].DesiredLevel.Price)
	}
}

// TestDiff_SamePriceNoCorrect: ensure Price.Equal() doesn't trigger CORRECT on equal prices.
func TestDiff_SamePriceNoCorrect(t *testing.T) {
	tracker := NewTracker()
	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96450.00", "0.85000"),
	}
	addResting(tracker, "MM-BTC-USDT-ASK-01", "SELL", "96450.00", "0.85000")

	entries := Diff(desired, tracker, testMarket, testCfg())
	if len(entries) != 0 {
		t.Errorf("same price should produce no CORRECT, got %d entries", len(entries))
	}
}

// TestDiff_MultipleMarkets: diff only processes orders for the specified market.
func TestDiff_MultipleMarkets(t *testing.T) {
	tracker := NewTracker()

	// ETH order in tracker — should NOT appear in BTC diff
	tracker.orders["MM-ETH-USDT-ASK-01"] = &LiveOrder{
		LevelID:  "MM-ETH-USDT-ASK-01",
		MarketID: "ETH-USDT",
		Status:   StatusResting,
	}

	desired := []pricing.PriceLevel{
		desiredLevel("MM-BTC-USDT-ASK-01", "SELL", "96500.00", "0.85000"),
	}
	entries := Diff(desired, tracker, testMarket, testCfg())

	// Should only see CREATE for BTC, not CANCEL for ETH
	if len(entries) != 1 || entries[0].Action != DiffCreate {
		t.Errorf("expected 1 CREATE for BTC, got %d entries", len(entries))
	}
}

// TestTracker_CommittedBase: verifies committed base uses RemainingQty not OriginalQty.
func TestTracker_CommittedBase(t *testing.T) {
	tracker := NewTracker()
	tracker.orders["MM-BTC-USDT-ASK-01"] = &LiveOrder{
		LevelID:      "MM-BTC-USDT-ASK-01",
		MarketID:     testMarket,
		Side:         "SELL",
		OriginalQty:  qty("1.00000"),
		RemainingQty: qty("0.60000"), // partially filled
		Status:       StatusResting,
	}
	tracker.orders["MM-BTC-USDT-ASK-02"] = &LiveOrder{
		LevelID:      "MM-BTC-USDT-ASK-02",
		MarketID:     testMarket,
		Side:         "SELL",
		OriginalQty:  qty("0.85000"),
		RemainingQty: qty("0.85000"),
		Status:       StatusResting,
	}

	committed := tracker.CommittedBase(testMarket)
	expected := qty("1.45000") // 0.60 + 0.85 (not 1.00 + 0.85)
	if !committed.Equal(expected) {
		t.Errorf("CommittedBase = %s, want %s (must use RemainingQty, not OriginalQty)", committed, expected)
	}
}

// TestTracker_CommittedQuote: verifies PENDING orders are included in commitment.
func TestTracker_CommittedQuote(t *testing.T) {
	tracker := NewTracker()
	// RESTING BUY
	tracker.orders["MM-BTC-USDT-BID-01"] = &LiveOrder{
		LevelID:      "MM-BTC-USDT-BID-01",
		MarketID:     testMarket,
		Side:         "BUY",
		Price:        price("96411.00"),
		RemainingQty: qty("0.85000"),
		Status:       StatusResting,
	}
	// PENDING BUY — must also be included in committed quote
	tracker.orders["MM-BTC-USDT-BID-02"] = &LiveOrder{
		LevelID:      "MM-BTC-USDT-BID-02",
		MarketID:     testMarket,
		Side:         "BUY",
		Price:        price("96372.00"),
		RemainingQty: qty("0.85000"),
		Status:       StatusPending,
	}

	committed := tracker.CommittedQuote(testMarket)
	// 0.85 × 96411 + 0.85 × 96372 = 81949.35 + 81916.20 = 163865.55
	expected := qty("0.85").Mul(price("96411.00")).Add(qty("0.85").Mul(price("96372.00")))
	if !committed.Equal(expected) {
		t.Errorf("CommittedQuote = %s, want %s", committed, expected)
	}
}

// TestClientOrderID: verifies format.
func TestClientOrderID(t *testing.T) {
	got := ClientOrderID("MM-BTC-USDT-ASK-01", 3)
	want := "MM-BTC-USDT-ASK-01-G003"
	if got != want {
		t.Errorf("ClientOrderID = %q, want %q", got, want)
	}

	// Zero-padded
	got = ClientOrderID("MM-BTC-USDT-ASK-01", 42)
	want = "MM-BTC-USDT-ASK-01-G042"
	if got != want {
		t.Errorf("ClientOrderID(42) = %q, want %q", got, want)
	}
}
