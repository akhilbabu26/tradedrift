package handler

import (
	"net/http"

	"go.uber.org/zap"

	platformjwt "tradedrift/platform/jwt"
)

// NewRouter wires all admin routes with appropriate middleware chains.
// Route convention: POST /api/v1/admin/<resource>/<id>/<action>
func NewRouter(h *AdminHandler, jwtValidator *platformjwt.HMACValidator, log *zap.Logger) http.Handler {
	mux := http.NewServeMux()

	adminAuth := RequireAdmin(jwtValidator)

	// ── User management ───────────────────────────────────────────────────────
	mux.HandleFunc("POST /api/v1/admin/users/{user_id}/suspend",
		adminAuth(RequireIdempotencyKey(h.HandleSuspendUser)))

	mux.HandleFunc("POST /api/v1/admin/users/{user_id}/unsuspend",
		adminAuth(RequireIdempotencyKey(h.HandleUnsuspendUser)))

	// ── Wallet management ─────────────────────────────────────────────────────
	mux.HandleFunc("POST /api/v1/admin/users/{user_id}/wallets/{asset}/freeze",
		adminAuth(RequireIdempotencyKey(h.HandleFreezeWallet)))

	// ── Market management ─────────────────────────────────────────────────────
	mux.HandleFunc("POST /api/v1/admin/markets/{market_id}/halt",
		adminAuth(RequireIdempotencyKey(h.HandleHaltMarket)))

	// ── Health / Readiness ────────────────────────────────────────────────────
	mux.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]bool{"ok": true})
	})
	mux.HandleFunc("GET /ready", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]bool{"ready": true})
	})

	_ = log // available for structured access logging middleware

	return LoggingMiddleware(mux)
}
