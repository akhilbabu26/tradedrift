// skew.go computes how many bid/ask levels to activate based on effective inventory.
// In V1, LE uses a static reference price. Skew reduces active levels when inventory
// drops below configured thresholds, protecting against over-commitment.
//
// Skew does NOT reprice levels — it only reduces the number of active levels.
// Dynamic repricing is reserved for V2.
//
//	NORMAL   → bidCount = 12, askCount = 12   (full ladder both sides)
//	LOW      → bidCount = 12, askCount = 6    (base running low, reduce sells)
//	CRITICAL → bidCount = 12, askCount = 0    (no asks — stop selling base)
//
// Similarly for USDT (bid side):
//
//	LOW      → bidCount = 6,  askCount = 12
//	CRITICAL → bidCount = 0,  askCount = 12
package inventory

import (
	"tradedrift/services/liquidity-engine/internal/config"

	"github.com/shopspring/decimal"
	"go.uber.org/zap"
)

// InventoryTier represents how much inventory the LE currently has.
type InventoryTier int

const (
	TierNormal   InventoryTier = iota // >  MinBase / MinQuote
	TierLow                           // <= MinBase / MinQuote but > Critical
	TierCritical                      // <= CriticalBase / CriticalQuote
)

// Skew holds the computed bid/ask level counts for a market reconcile cycle.
type Skew struct {
	BidCount int
	AskCount int
	BaseTier  InventoryTier
	QuoteTier InventoryTier
}

// ComputeSkew computes the number of active bid/ask levels based on effective inventory.
// effectiveBase: EffectiveAvailableBase(marketID)
// effectiveQuote: EffectiveAvailableQuote(allMarkets) — shared USDT pool
func ComputeSkew(mc *config.MarketConfig, effectiveBase, effectiveQuote decimal.Decimal, logger *zap.Logger) Skew {
	maxLevels := mc.LevelCount

	// --- ASK side: driven by base asset inventory ---
	baseTier := TierNormal
	askCount := maxLevels
	switch {
	case effectiveBase.LessThanOrEqual(mc.CriticalBase):
		baseTier = TierCritical
		askCount = 0
	case effectiveBase.LessThanOrEqual(mc.MinBase):
		baseTier = TierLow
		askCount = maxLevels / 2
	}

	// --- BID side: driven by USDT (quote) inventory ---
	quoteTier := TierNormal
	bidCount := maxLevels
	switch {
	case effectiveQuote.LessThanOrEqual(mc.CriticalQuote):
		quoteTier = TierCritical
		bidCount = 0
	case effectiveQuote.LessThanOrEqual(mc.MinQuote):
		quoteTier = TierLow
		bidCount = maxLevels / 2
	}

	if baseTier != TierNormal || quoteTier != TierNormal {
		logger.Warn("inventory skew active",
			zap.String("market_id", mc.MarketID),
			zap.String("effective_base", effectiveBase.String()),
			zap.String("effective_quote", effectiveQuote.String()),
			zap.Int("bid_count", bidCount),
			zap.Int("ask_count", askCount),
			zap.Int("base_tier", int(baseTier)),
			zap.Int("quote_tier", int(quoteTier)))
	}

	return Skew{
		BidCount:  bidCount,
		AskCount:  askCount,
		BaseTier:  baseTier,
		QuoteTier: quoteTier,
	}
}
