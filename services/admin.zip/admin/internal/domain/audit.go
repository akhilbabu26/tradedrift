package domain

import "time"

// AuditLog is the append-only record of an administrative action.
// Once created it is immutable — enforced by PostgreSQL triggers.
type AuditLog struct {
	ID          string            `json:"id"`           // UUIDv7
	AdminID     string            `json:"admin_id"`
	OperationID *string           `json:"operation_id,omitempty"`
	RequestID   string            `json:"request_id"`
	Action      string            `json:"action"`       // 'SUSPEND_USER' | 'FREEZE_WALLET' | etc.
	TargetType  string            `json:"target_type"`  // 'USER' | 'WALLET' | 'MARKET'
	TargetID    string            `json:"target_id"`
	Reason      string            `json:"reason"`
	Metadata    map[string]string `json:"metadata"`
	IPAddress   string            `json:"ip_address,omitempty"`
	UserAgent   string            `json:"user_agent,omitempty"`
	CreatedAt   time.Time         `json:"created_at"`
}

// Audit action constants
const (
	ActionSuspendUser    = "SUSPEND_USER"
	ActionUnsuspendUser  = "UNSUSPEND_USER"
	ActionFreezeWallet   = "FREEZE_WALLET"
	ActionUnfreezeWallet = "UNFREEZE_WALLET"
	ActionHaltMarket     = "HALT_MARKET"
	ActionResumeMarket   = "RESUME_MARKET"
)

// Audit target type constants
const (
	TargetTypeUser   = "USER"
	TargetTypeWallet = "WALLET"
	TargetTypeMarket = "MARKET"
)
