package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"go.uber.org/zap"

	platformpg "tradedrift/platform/postgres"
	platformjwt "tradedrift/platform/jwt"
	"tradedrift/services/admin/internal/client"
	"tradedrift/services/admin/internal/config"
	"tradedrift/services/admin/internal/handler"
	postgresRepo "tradedrift/services/admin/internal/repository/postgres"
	"tradedrift/services/admin/internal/service"
)

func main() {
	// 1. Logger
	log, _ := zap.NewProduction()
	defer log.Sync()
	log.Info("Starting TradeDrift Admin Service...")

	// 2. Config
	cfg := config.Load()

	// 3. Graceful shutdown context
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	// 4. Database Migrations
	migrationDir := "migrations"
	if _, err := os.Stat(migrationDir); os.IsNotExist(err) {
		migrationDir = "services/admin/migrations"
	}
	log.Info("Running admin migrations...", zap.String("dir", migrationDir))
	if err := platformpg.RunMigrations(cfg.PostgresDSN, migrationDir); err != nil {
		log.Warn("Could not run database migrations automatically", zap.Error(err))
	}

	// 5. Database Connection Pool
	poolCfg, err := pgxpool.ParseConfig(cfg.PostgresDSN)
	if err != nil {
		log.Fatal("Failed to parse postgres DSN", zap.Error(err))
	}
	poolCfg.MaxConns = 20
	poolCfg.MinConns = 5

	dbPool, err := pgxpool.NewWithConfig(ctx, poolCfg)
	if err != nil {
		log.Fatal("Failed to connect to PostgreSQL", zap.Error(err))
	}
	defer dbPool.Close()

	// 6. Repositories
	txMgr := postgresRepo.NewTxManager(dbPool)
	opsRepo := postgresRepo.NewOperationsRepo(dbPool)
	outboxRepo := postgresRepo.NewOutboxRepo(dbPool)
	sagaRepo := postgresRepo.NewSagaRepo(dbPool)

	// 7. gRPC Clients
	authCli, err := client.NewAuthClient(cfg.AuthGRPCAddr)
	if err != nil {
		log.Error("Failed to initialize Auth gRPC client", zap.String("addr", cfg.AuthGRPCAddr), zap.Error(err))
	} else {
		defer authCli.Close()
	}

	walletCli, err := client.NewWalletClient(cfg.WalletGRPCAddr)
	if err != nil {
		log.Error("Failed to initialize Wallet gRPC client", zap.String("addr", cfg.WalletGRPCAddr), zap.Error(err))
	} else {
		defer walletCli.Close()
	}

	// 8. Services
	adminSvc := service.NewAdminService(txMgr, opsRepo, authCli, walletCli, log)

	// 9. Background workers
	sagaWorker := service.NewSagaWorker(sagaRepo, opsRepo, authCli, log, cfg.SagaInterval)
	sagaWorker.Start(ctx)
	defer sagaWorker.Stop()

	outboxPub := service.NewOutboxPublisher(outboxRepo, log, cfg.OutboxInterval)
	outboxPub.Start(ctx)
	defer outboxPub.Stop()

	// 10. JWT Validator (stateless HMAC — no Redis)
	jwtValidator := platformjwt.NewHMACValidator([]byte(cfg.JWTSecret))

	// 11. HTTP Server
	adminHandler := handler.NewAdminHandler(adminSvc, log)
	router := handler.NewRouter(adminHandler, jwtValidator, log)

	srv := &http.Server{
		Addr:         fmt.Sprintf(":%s", cfg.Port),
		Handler:      router,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	go func() {
		log.Info("Admin Service HTTP server listening", zap.String("addr", srv.Addr))
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatal("HTTP server failed", zap.Error(err))
		}
	}()

	<-ctx.Done()
	log.Info("Shutting down Admin Service...")

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		log.Error("HTTP server shutdown error", zap.Error(err))
	}

	log.Info("Admin Service stopped cleanly")
}
