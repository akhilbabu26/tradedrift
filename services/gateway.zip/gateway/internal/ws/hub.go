package ws

import (
	"encoding/json"
	"strings"
	"sync"
	"sync/atomic"

	"go.uber.org/zap"
)

// SnapshotProvider fetches immediate depth and ticker snapshots upon client subscription.
type SnapshotProvider interface {
	GetImmediateOrderBook(marketID string) (*OrderBookDepthPayload, error)
	GetImmediateTicker(marketID string) (*TickerPayload, error)
}

// Hub manages WebSocket client connections, channel routing, and broadcast distribution.
type Hub struct {
	clients          map[*Client]bool
	subs             map[string]map[*Client]bool // stream -> set of clients
	marketSubs       map[string]int              // marketID -> count of active subscribers
	mu               sync.RWMutex
	logger           *zap.Logger
	snapshotProvider SnapshotProvider

	// Prometheus / Internal Observability Counters
	activeConnections int64
	messagesSentTotal int64
	messagesDroppedTotal int64
	slowClientsTotal     int64
}

// NewHub creates a new Hub instance.
func NewHub(logger *zap.Logger, provider SnapshotProvider) *Hub {
	return &Hub{
		clients:          make(map[*Client]bool),
		subs:             make(map[string]map[*Client]bool),
		marketSubs:       make(map[string]int),
		logger:           logger,
		snapshotProvider: provider,
	}
}

// Register adds a new client to the hub.
func (h *Hub) Register(c *Client) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.clients[c] = true
	atomic.AddInt64(&h.activeConnections, 1)
	h.logger.Debug("Client registered", zap.String("user_id", c.UserID()))
}

// Unregister removes a client and cleans up all its active subscriptions.
func (h *Hub) Unregister(c *Client) {
	h.mu.Lock()
	defer h.mu.Unlock()

	if !h.clients[c] {
		return
	}
	delete(h.clients, c)
	atomic.AddInt64(&h.activeConnections, -1)

	// Clean up all channel subscriptions for this client
	for _, stream := range c.Subscriptions() {
		h.removeSubscriptionLocked(c, stream)
	}

	h.logger.Debug("Client unregistered", zap.String("user_id", c.UserID()))
}

// HandleClientFrame processes an inbound client event through the 6-step validation pipeline.
func (h *Hub) HandleClientFrame(c *Client, frame InboundFrame) {
	switch frame.Event {
	case "ping":
		c.SendPong()

	case "subscribe":
		for _, stream := range frame.Streams {
			h.handleSubscribe(c, stream)
		}

	case "unsubscribe":
		for _, stream := range frame.Streams {
			h.handleUnsubscribe(c, stream)
		}

	default:
		c.SendControlError("UNKNOWN_EVENT", "unrecognized event action")
	}
}

// handleSubscribe executes the 6-step pre-registration validation pipeline.
func (h *Hub) handleSubscribe(c *Client, stream string) {
	stream = strings.TrimSpace(stream)
	if stream == "" {
		c.SendControlError("INVALID_STREAM", "stream name cannot be empty")
		return
	}

	streamType, target := ParseStreamType(stream)

	// Step 3 & 4: Authentication & Authorization Guard for Private Streams
	if streamType == StreamTypeNotification {
		if c.UserID() == "" {
			c.SendControlError("UNAUTHORIZED", "authentication required for private notifications")
			return
		}
		if c.UserID() != target {
			c.SendControlError("FORBIDDEN", "cannot subscribe to other user's notification stream")
			h.logger.Warn("Unauthorized private subscription attempt rejected",
				zap.String("client_user_id", c.UserID()),
				zap.String("target_user_id", target),
			)
			return
		}
	}

	// Step 5: Limit Validation (Max 50 subscriptions per socket)
	if !c.AddSubscription(stream) {
		c.SendControlError("SUBSCRIPTION_LIMIT_EXCEEDED", "max 50 active subscriptions allowed per connection")
		return
	}

	// Step 6: Deliver Immediate Snapshot (Depth & Ticker) prior to next broadcast cycle
	h.deliverImmediateSnapshot(c, streamType, target)

	// Step 7: Hub Registration
	h.mu.Lock()
	defer h.mu.Unlock()

	if _, ok := h.subs[stream]; !ok {
		h.subs[stream] = make(map[*Client]bool)
	}
	h.subs[stream][c] = true

	// If this is a market stream, increment market subscriber counter for on-demand polling
	if target != "" && (streamType == StreamTypeOrderBook || streamType == StreamTypeTrades || streamType == StreamTypeTicker) {
		h.marketSubs[target]++
	}

	h.logger.Debug("Client subscribed to stream",
		zap.String("stream", stream),
		zap.String("user_id", c.UserID()),
	)
}

// deliverImmediateSnapshot dispatches initial depth or ticker snapshot upon subscription.
func (h *Hub) deliverImmediateSnapshot(c *Client, streamType, marketID string) {
	if h.snapshotProvider == nil || marketID == "" {
		return
	}

	switch streamType {
	case StreamTypeOrderBook:
		if snapshot, err := h.snapshotProvider.GetImmediateOrderBook(marketID); err == nil && snapshot != nil {
			env := OutboundEnvelope{
				Stream: "market:orderbook:" + marketID,
				Data:   snapshot,
			}
			if bytes, err := json.Marshal(env); err == nil {
				c.Send(StreamTypeOrderBook, bytes)
			}
		}

	case StreamTypeTicker:
		if ticker, err := h.snapshotProvider.GetImmediateTicker(marketID); err == nil && ticker != nil {
			env := OutboundEnvelope{
				Stream: "market:ticker:" + marketID,
				Data:   ticker,
			}
			if bytes, err := json.Marshal(env); err == nil {
				c.Send(StreamTypeTicker, bytes)
			}
		}
	}
}

// handleUnsubscribe unregisters a stream subscription for a client.
func (h *Hub) handleUnsubscribe(c *Client, stream string) {
	c.RemoveSubscription(stream)

	h.mu.Lock()
	defer h.mu.Unlock()
	h.removeSubscriptionLocked(c, stream)
}

func (h *Hub) removeSubscriptionLocked(c *Client, stream string) {
	clients, ok := h.subs[stream]
	if !ok {
		return
	}
	delete(clients, c)

	// Clean up market subscriber count
	streamType, target := ParseStreamType(stream)
	if target != "" && (streamType == StreamTypeOrderBook || streamType == StreamTypeTrades || streamType == StreamTypeTicker) {
		if count := h.marketSubs[target]; count > 0 {
			h.marketSubs[target]--
			if h.marketSubs[target] <= 0 {
				delete(h.marketSubs, target)
			}
		}
	}

	if len(clients) == 0 {
		delete(h.subs, stream)
	}
}

// Broadcast dispatches a message to all active subscribers of a channel.
func (h *Hub) Broadcast(channel string, payload []byte, streamType string) {
	h.mu.RLock()
	clients := make([]*Client, 0, len(h.subs[channel]))
	for c := range h.subs[channel] {
		clients = append(clients, c)
	}
	h.mu.RUnlock()

	for _, c := range clients {
		if c.Send(streamType, payload) {
			atomic.AddInt64(&h.messagesSentTotal, 1)
		}
	}
}

// GetActiveMarketIDs returns all markets that currently have at least one active subscriber.
func (h *Hub) GetActiveMarketIDs() []string {
	h.mu.RLock()
	defer h.mu.RUnlock()

	markets := make([]string, 0, len(h.marketSubs))
	for mkt := range h.marketSubs {
		markets = append(markets, mkt)
	}
	return markets
}

// HasSubscribers checks if a channel currently has at least 1 listener.
func (h *Hub) HasSubscribers(channel string) bool {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return len(h.subs[channel]) > 0
}

// Observability Helpers
func (h *Hub) RecordMessageDropped() {
	atomic.AddInt64(&h.messagesDroppedTotal, 1)
}

func (h *Hub) RecordSlowClientDisconnect() {
	atomic.AddInt64(&h.slowClientsTotal, 1)
}

func (h *Hub) ActiveConnections() int64 {
	return atomic.LoadInt64(&h.activeConnections)
}

func (h *Hub) MessagesSentTotal() int64 {
	return atomic.LoadInt64(&h.messagesSentTotal)
}

func (h *Hub) MessagesDroppedTotal() int64 {
	return atomic.LoadInt64(&h.messagesDroppedTotal)
}

func (h *Hub) SlowClientsTotal() int64 {
	return atomic.LoadInt64(&h.slowClientsTotal)
}
