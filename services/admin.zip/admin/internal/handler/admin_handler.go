package handler

import (
	"encoding/json"
	"errors"
	"net/http"

	"go.uber.org/zap"

	"tradedrift/services/admin/internal/domain"
	"tradedrift/services/admin/internal/service"
)

// AdminHandler handles all administrative REST endpoints.
type AdminHandler struct {
	adminSvc *service.AdminService
	log      *zap.Logger
}

// NewAdminHandler constructs the handler.
func NewAdminHandler(adminSvc *service.AdminService, log *zap.Logger) *AdminHandler {
	return &AdminHandler{adminSvc: adminSvc, log: log}
}

// HandleSuspendUser handles POST /api/v1/admin/users/{user_id}/suspend
func (h *AdminHandler) HandleSuspendUser(w http.ResponseWriter, r *http.Request) {
	adminID := AdminIDFromContext(r.Context())
	requestID := RequestIDFromContext(r.Context())
	idempotencyKey := IdempotencyKeyFromContext(r.Context())

	userID := r.PathValue("user_id")
	if userID == "" {
		writeJSON(w, http.StatusBadRequest, errorResponse("user_id path parameter is required"))
		return
	}

	var body SuspendUserRequest
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body.Reason == "" {
		writeJSON(w, http.StatusBadRequest, errorResponse("reason is required"))
		return
	}

	op, err := h.adminSvc.SuspendUser(r.Context(), service.SuspendUserRequest{
		AdminID:        adminID,
		IdempotencyKey: idempotencyKey,
		RequestID:      requestID,
		TargetUserID:   userID,
		Reason:         body.Reason,
		IPAddress:      r.RemoteAddr,
		UserAgent:      r.UserAgent(),
	})
	if err != nil {
		h.handleServiceError(w, err)
		return
	}

	writeJSON(w, http.StatusOK, ToOperationDTO(op))
}

// HandleUnsuspendUser handles POST /api/v1/admin/users/{user_id}/unsuspend
func (h *AdminHandler) HandleUnsuspendUser(w http.ResponseWriter, r *http.Request) {
	// Unsuspend: future — currently returns 501 Not Implemented placeholder.
	writeJSON(w, http.StatusNotImplemented, errorResponse("unsuspend not yet implemented"))
}

// HandleFreezeWallet handles POST /api/v1/admin/users/{user_id}/wallets/{asset}/freeze
func (h *AdminHandler) HandleFreezeWallet(w http.ResponseWriter, r *http.Request) {
	adminID := AdminIDFromContext(r.Context())
	requestID := RequestIDFromContext(r.Context())
	idempotencyKey := IdempotencyKeyFromContext(r.Context())

	userID := r.PathValue("user_id")
	asset := r.PathValue("asset")
	if userID == "" || asset == "" {
		writeJSON(w, http.StatusBadRequest, errorResponse("user_id and asset path parameters are required"))
		return
	}

	var body FreezeWalletRequest
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body.Reason == "" {
		writeJSON(w, http.StatusBadRequest, errorResponse("reason is required"))
		return
	}

	op, err := h.adminSvc.FreezeWallet(r.Context(), service.FreezeWalletRequest{
		AdminID:        adminID,
		IdempotencyKey: idempotencyKey,
		RequestID:      requestID,
		TargetUserID:   userID,
		Asset:          asset,
		Freeze:         body.Freeze,
		Reason:         body.Reason,
		IPAddress:      r.RemoteAddr,
		UserAgent:      r.UserAgent(),
	})
	if err != nil {
		h.handleServiceError(w, err)
		return
	}

	writeJSON(w, http.StatusOK, ToOperationDTO(op))
}

// HandleHaltMarket handles POST /api/v1/admin/markets/{market_id}/halt
func (h *AdminHandler) HandleHaltMarket(w http.ResponseWriter, r *http.Request) {
	adminID := AdminIDFromContext(r.Context())
	requestID := RequestIDFromContext(r.Context())
	idempotencyKey := IdempotencyKeyFromContext(r.Context())

	marketID := r.PathValue("market_id")
	if marketID == "" {
		writeJSON(w, http.StatusBadRequest, errorResponse("market_id path parameter is required"))
		return
	}

	var body HaltMarketRequest
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body.Reason == "" {
		writeJSON(w, http.StatusBadRequest, errorResponse("reason is required"))
		return
	}

	op, err := h.adminSvc.HaltMarket(r.Context(), service.HaltMarketRequest{
		AdminID:        adminID,
		IdempotencyKey: idempotencyKey,
		RequestID:      requestID,
		MarketID:       marketID,
		Reason:         body.Reason,
		IPAddress:      r.RemoteAddr,
		UserAgent:      r.UserAgent(),
	})
	if err != nil {
		h.handleServiceError(w, err)
		return
	}

	writeJSON(w, http.StatusOK, ToOperationDTO(op))
}

// handleServiceError maps domain errors to appropriate HTTP status codes.
func (h *AdminHandler) handleServiceError(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, domain.ErrOperationInProgress):
		writeJSON(w, http.StatusConflict, errorResponse(err.Error()))
	case errors.Is(err, domain.ErrInvalidTarget), errors.Is(err, domain.ErrInvalidReason):
		writeJSON(w, http.StatusBadRequest, errorResponse(err.Error()))
	case errors.Is(err, domain.ErrAuthUnavailable), errors.Is(err, domain.ErrWalletUnavailable):
		writeJSON(w, http.StatusServiceUnavailable, errorResponse("downstream service unavailable"))
	default:
		h.log.Error("admin handler: unexpected error", zap.Error(err))
		writeJSON(w, http.StatusInternalServerError, errorResponse("internal server error"))
	}
}
